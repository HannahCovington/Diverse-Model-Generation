import java.io.*;
import java.util.*;

public class ProbDistribImporter {
	
	int arbitraryExpressionMax = 100; //a number that ensures that all entries in each distribution are included
	public double[][][][] constantCharacteristicProbDistrib = new double[ModelGenerator.numConstantChar][ModelGenerator.numOfClimateZones][ModelGenerator.numOfIncomeLevels][arbitraryExpressionMax];
	public double[][][] fridgeProbDistrib = new double[ModelGenerator.numFridgeChar][ModelGenerator.numOfIncomeLevels][arbitraryExpressionMax];
	public double[][][][] applianceProbDistrib = new double[ModelGenerator.numAppl][ModelGenerator.numApplChar][ModelGenerator.numOfIncomeLevels][arbitraryExpressionMax];
	public double[][][][][] fridgekWhInformation = new double[2][5][6][5][1];
	
	public ProbDistribImporter() throws IOException {
		readInConstantProbDistrib();
		readInApplianceProbDistrib();
		readInFridgeProbDistrib();
		readInFridgekWh();
	}
	
	private void readInFridgekWh() throws IOException{
		//reading it in
		ArrayList<String> fileContents = new ArrayList<String>();
        BufferedReader br = new BufferedReader(new FileReader(ModelGenerator.fridgekWhInfoFileName));
        String line;
        while( (line = br.readLine()) != null ) {
            fileContents.add(line);
        }
        br.close();
        //Splitting into a readable double array line-by-line
        double[] currentLine = new double[4];
        
        for(int i = 1; i<fileContents.size();i++){
            currentLine = ConvertStringArrayToDoubleArray(fileContents.get(i).split(","));
            fridgekWhInformation[(int)currentLine[0]][(int)currentLine[1]][(int)currentLine[2]][(int)currentLine[3]][0] = currentLine[4];
        }
	}
	private void readInFridgeProbDistrib() throws IOException {
		//Read the file into an ArrayList
		BufferedReader br_fridge = new BufferedReader(new FileReader(ModelGenerator.fridgeProbFile));
        ArrayList<String> fileContents_fridge = new ArrayList<String>();
        String line;
        while( (line = br_fridge.readLine()) != null ) {
        	fileContents_fridge.add(line);
        }
        br_fridge.close();
        
        //Insert the data into an organized array
        int characteristicCount = -1;
        int income = -1;
        double[] currentProbs;
        for(int i = 0; i < fileContents_fridge.size(); i++){
        	//indication of characteristic changing
            if(fileContents_fridge.get(i).contains("###")){ 
                characteristicCount++;
            //indication that the income level is changing
            }else if(fileContents_fridge.get(i).contains("INCOME")){ 
            	income = Integer.valueOf(ConvertStringArrayToStringList(fileContents_fridge.get(i).split(",")).get(1));
            //ignore blank spaces and notes
            }else if(fileContents_fridge.get(i).equals("")||fileContents_fridge.get(i).contains("=")){   
                continue;
            //break probability distribution up into the proper space in the array
            }else{
            	currentProbs = ConvertStringArrayToDoubleArray(fileContents_fridge.get(i).split(","));
                for (int index = 0; index < arbitraryExpressionMax; index++){
                	fridgeProbDistrib[characteristicCount][income][index] = currentProbs[index];
                }
            }
        }
	}
	private void readInApplianceProbDistrib() throws IOException{
		//Read the file into an ArrayList
		BufferedReader br_app = new BufferedReader(new FileReader(ModelGenerator.applianceProbFile));
        ArrayList<String> fileContents_app = new ArrayList<String>();
        String line;
        while( (line = br_app.readLine()) != null ) {
            fileContents_app.add(line);
        }
        br_app.close();
        
        //Insert the data into an organized array
        int characteristicCount = -1;
        int applCount = -1;
        int income = -1;
        double[] currentProbs;
        for(int i = 0; i < fileContents_app.size(); i++){
        	//indication of income level changing
            if(fileContents_app.get(i).contains("###")){ 
            	income = Integer.valueOf(ConvertStringArrayToStringList(fileContents_app.get(i).split(",")).get(1));
            	/*
                if(fileContents_app.get(i).contains("Low")){
                	income = 0;
                }else if(fileContents_app.get(i).contains("Low-Middle")){
                	income = 1;
                }else if(fileContents_app.get(i).contains("Middle")) {
                	income = 2;
	            }else if(fileContents_app.get(i).contains("Middle-High")){
	            	income = 3;
	            }else if(fileContents_app.get(i).contains("High")) {
	            	income = 4;
	            }
	            */
            //indication that the appliance is changing
            }else if(fileContents_app.get(i).contains("===")){ 
            	characteristicCount = -1;
            	if(fileContents_app.get(i).contains("DishWasher")){
                    applCount = 0;
                }else if(fileContents_app.get(i).contains("ClothesWasher")){
                	applCount = 1;
                }else if(fileContents_app.get(i).contains("ClothesDryer")){
                	applCount = 2;
                }else if(fileContents_app.get(i).contains("Cooktop")){
                	applCount = 3;
                }else if(fileContents_app.get(i).contains("Oven")){
                	applCount = 4;
                }
            //indication that the characteristic is changing
            }else if(fileContents_app.get(i).contains("*")) {
            	characteristicCount++;
            //ignore blank spaces  
            }else if(fileContents_app.get(i).equals("")){   
                continue;
            //break probability distribution up into the proper space in the array
            }else{
                currentProbs = ConvertStringArrayToDoubleArray(fileContents_app.get(i).split(","));
                for (int index = 0; index < arbitraryExpressionMax; index++){
                	applianceProbDistrib[applCount][characteristicCount][income][index] = currentProbs[index];
                }
            }
        }
	}
	private void readInConstantProbDistrib() throws IOException{
		
		//Read the file into an ArrayList
		BufferedReader br_cc = new BufferedReader(new FileReader(ModelGenerator.constantProbFile));
        ArrayList<String> fileContents_cc = new ArrayList<String>();
        String line;
        while( (line = br_cc.readLine()) != null ) {
            fileContents_cc.add(line);
        }
        br_cc.close();
        
        //Insert the data into an organized array
        int characteristicCount = -1;
        int IECC = -1;
        int income = -1;
        double[] currentProbs;
        for(int i = 0; i < fileContents_cc.size(); i++){
        	//indication of new characteristic
            if(fileContents_cc.get(i).contains("###")){ 
                characteristicCount++;
            //indication that climate and/or income is changing
            }else if(fileContents_cc.get(i).contains("IECC")){ 
                switch(ConvertStringArrayToStringList(fileContents_cc.get(i).split(",")).get(1)){
                    case "1A-2A":
                        IECC = 0;
                        break;
                    case "2B":
                        IECC = 1;
                        break;
                    case "3A":
                        IECC = 2;
                        break;
                    case "3B-4B":
                        IECC = 3;
                        break;
                    case "3C":
                        IECC = 4;
                        break;
                    case "4A":
                        IECC = 5;
                        break;
                    case "4C":
                        IECC = 6;
                        break;
                    case "5A":
                        IECC = 7;
                        break;
                    case "5B-5C":
                        IECC = 8;
                        break;
                    case "6A-6B":
                        IECC = 9;
                        break;
                    case "7A-7B-7AK-8AK":
                        IECC = 10;    
                        break;
                }
                
                income = Integer.valueOf(ConvertStringArrayToStringList(fileContents_cc.get(i).split(",")).get(3));
                /*
                if(ConvertStringArrayToStringList(fileContents_cc.get(i).split(",")).get(3).equals("L")){
                    income = 0;
                }else if(ConvertStringArrayToStringList(fileContents_cc.get(i).split(",")).get(3).equals("LM")){
                    income = 1;
                }else if(ConvertStringArrayToStringList(fileContents_cc.get(i).split(",")).get(3).equals("M")){
                    income = 2;
                }else if(ConvertStringArrayToStringList(fileContents_cc.get(i).split(",")).get(3).equals("UM")){
                    income = 3;
                }else if(ConvertStringArrayToStringList(fileContents_cc.get(i).split(",")).get(3).equals("U")){
                    income = 4;
                }
                */
            //ignore blank spaces  
            }else if(fileContents_cc.get(i).equals("") || fileContents_cc.get(i).contains("=")){   
                continue;
            //break probability distribution up into the proper space in the array
            }else{
                currentProbs = ConvertStringArrayToDoubleArray(fileContents_cc.get(i).split(","));
                for (int index = 0; index < arbitraryExpressionMax; index++){
                	constantCharacteristicProbDistrib[characteristicCount][IECC][income][index] = currentProbs[index];
                }
            }
        }
	}
	private double[] ConvertStringArrayToDoubleArray(String[] arrayForConversion){
        double[] output = new double [arbitraryExpressionMax];
        for(int i = 0; i<arbitraryExpressionMax;i++){    
            if(i<arrayForConversion.length){
                output[i] = Double.valueOf(arrayForConversion[i]);
            }else{
                output[i] = 0;
            }
        }
        return output;
    }
    private List<String> ConvertStringArrayToStringList(String[] arrayForConversion){
        List<String> output = new ArrayList<>();
        for(int i = 0; i<arrayForConversion.length;i++){    
            output.add(arrayForConversion[i]);
        }
        return output;
    }
}
