import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

public class ModelGenerator {
	
	public int simulationTimeStep = 12; //per hour 
	public String desiredUnits; 
	public int numberOfWeeks = 52;
	public String outputFileDirectory;
	public String incomeLevel;
	public String climateZone;
	public int numOfModels;
	public static int numOfIncomeLevels = 5;
	public static int numOfClimateZones = 11;
	public static int applianceTimeStep = 4; //per hour
	public static String constantProbFile = "Data\\ProbDistributions_ConstantCharacteristics.csv";
	public static String applianceProbFile = "Data\\ProbDistributions_Appliances.csv";
	public static String fridgeProbFile = "Data\\ProbDistributions_Fridge.csv";
	static String fridgekWhInfoFileName = "Data\\FridgeEnergyConsumptionData.csv";
	public static int numConstantChar = 21;
	public static int numApplChar = 11;
	public static int numAppl = 5;
	public static int numFridgeChar = 5;
	public String outputFileNameModel;
	public String outputFileNameInfo;
	String[] applianceNames = {"DishWasher","ClothesWasher","ClothesDryer","Cooktop","Oven"};
	
	public ModelGenerator(String oFD, String iL, String cZ, int nOM, int nOIL, String dU) throws IOException {
		
		//GET USER INPUT=================================================================================================
		outputFileDirectory = oFD;
		incomeLevel = iL;
		climateZone = cZ;
		numOfModels = nOM;
		numOfIncomeLevels = nOIL;
		desiredUnits = dU;
		int climateZoneNumValue = getClimateZoneNumValue(climateZone);
		int incomeLevelNumValue = getIncomeLevelNumValue(incomeLevel);
		//================================================================================================================
		
		//IMPORT PROBABILITY DISTRIBUTIONS================================================================================
		ProbDistribImporter pDI = new ProbDistribImporter(); //pDI contains constant, appliance, and fridge distributions
		//================================================================================================================
		
		//DEFINING OUTPUT FILE FOR INFO SHEET ABOUT GENERATED HOUSEHOLDS==================================================
		outputFileNameInfo = outputFileDirectory+"\\"+climateZone+"_"+incomeLevel+"_INFO.csv";
		InfoFileWriter infoWriter = new InfoFileWriter(outputFileNameInfo);
		infoWriter.writeInfoHeader();
		//================================================================================================================
		
		//LOOP FOR THE NUMBER OF REQUESTED MODELS. ========================================================
		for(int currentHouseNum = 1 ; currentHouseNum <= numOfModels; currentHouseNum++) {
		//================================================================================================================
		
			//WRITE INITIAL HOUSE INFO FOR THE INFO FILE======================================================================
			infoWriter.append(incomeLevel+","+climateZone+","+currentHouseNum+",");
			//================================================================================================================
			
			//DEFINE .IDF OUTPUT FILE FOR THIS MODEL INSTANCE=================================================================
			outputFileNameModel = outputFileDirectory+"\\"+climateZone+"_"+incomeLevel+"_House"+currentHouseNum+".idf";
			ModelFileWriter modelWriter = new ModelFileWriter(outputFileNameModel);
			//================================================================================================================
			
			
			//SELECT AND WRITE CONSTANT CHARACTERISTICS=======================================================================
			int[] selectedConstantExpressions = new int[numConstantChar];
			for(int i = 0; i < numConstantChar; i++) {
				selectedConstantExpressions[i] = selectWithProbDistrib(pDI.constantCharacteristicProbDistrib[i][climateZoneNumValue][incomeLevelNumValue]);
				if(i == 12) { //testing to ensure that the heating set point is below the cooling set point
					if(selectedConstantExpressions[12]>=selectedConstantExpressions[11]) { //if not, reselect both
						i = 10;
					}
				}
			}
			System.out.println("HOUSE "+currentHouseNum+"\n\tConstant Char Selections: "+Arrays.toString(selectedConstantExpressions)+"\n");
			infoWriter.writeConstantCharInfo(selectedConstantExpressions); 
				//Note: copying over skeleton model needs to be done after constant characteristic selection because it depends on heating type/fuel
				//It also needs to be done before the writing process begins.
			modelWriter.copyOverSkeletonModel(selectedConstantExpressions[6], selectedConstantExpressions[7], climateZone);
			modelWriter.writeConstantCharIDF(selectedConstantExpressions,outputFileNameModel,getClimateZoneNumValue(climateZone),simulationTimeStep, desiredUnits);
			//================================================================================================================
			
			
			//SELECT AND WRITE REFRIGERATOR CHARACTERISTICS===================================================================	
			
			//First, the number of refrigerators
			int numberOfFridges = selectWithProbDistrib(pDI.fridgeProbDistrib[4][incomeLevelNumValue]);
			infoWriter.append(numberOfFridges+",");
			
			//Next, get characteristic expressions for each refrigerator
			int[][] selectedFridgeExpressions = new int[numberOfFridges][numFridgeChar - 1];
			System.out.println("\tFridge Selections:\n");
			for(int i = 0; i < numberOfFridges; i++) {
				for(int j = 0; j < numFridgeChar - 1; j++) { //don't include fridge number in this, thus the '-1'
					selectedFridgeExpressions[i][j] = selectWithProbDistrib(pDI.fridgeProbDistrib[j][incomeLevelNumValue]);
				}
				System.out.println("\t\tFridge #"+i+": "+Arrays.toString(selectedFridgeExpressions[i])+"\n");
			}
			infoWriter.writeFridgeCharInfo(numberOfFridges, selectedFridgeExpressions);
			modelWriter.writeFridgeIDF(numberOfFridges, selectedFridgeExpressions, pDI.fridgekWhInformation);
			//================================================================================================================	
			
			
			//SELECT AND WRITE APPLIANCE CHARACTERISTICS AND SCHEDULES========================================================
			int numberOfApplianceInstances = -1;
			int fuelType = -1;
			boolean isEnergyStar = false;
			String applianceInstanceName;
			ArrayList<Boolean> applianceEnergyStarsStorage = new ArrayList<Boolean>();
			ArrayList<Double> applianceWattagesStorage = new ArrayList<Double>();
			
			
			//Write the "Off Day" schedule to E+
			modelWriter.writeApplianceOffDay(applianceTimeStep);
			
			//Characteristics and Scheduling
			for(int i = 0; i < numAppl; i++) { //repeat for each appliance type
				//Clear out any old information from previous appliance type
				applianceEnergyStarsStorage.clear();
				applianceWattagesStorage.clear();
				
				//Whether the appliance is present. If applicable, how many of this appliance type is in the house?
				numberOfApplianceInstances = selectWithProbDistrib(pDI.applianceProbDistrib[i][2][incomeLevelNumValue]);
				System.out.println("\tNumber of "+applianceNames[i]+"s: "+ numberOfApplianceInstances);
				
				//Determine fuel type (Note: All appliance instances of a certain type will have the same fuel. Eg. All cooktops)
				fuelType = selectWithProbDistrib(pDI.applianceProbDistrib[i][9][incomeLevelNumValue]);
				System.out.println("\t\tFuel: "+fuelType);
				
				for(int j = 0; j<numberOfApplianceInstances;j++) { //Repeat for each appliance instance
					//Get name for modelWriter
					if(numberOfApplianceInstances == 1) {applianceInstanceName = applianceNames[i];}
					else {applianceInstanceName = applianceNames[i]+(j+1);}
					
					//Determine if appliance instance is EnergyStar
					if(selectWithProbDistrib(pDI.applianceProbDistrib[i][8][incomeLevelNumValue])==0){isEnergyStar = false;
					}else {isEnergyStar = true;}
					System.out.println("\t\t#"+(j+1)+" EnergyStar: "+isEnergyStar);
					applianceEnergyStarsStorage.add(isEnergyStar);
					
					//Retrieving wattage based on fuel and Energy Star status
					double wattage = -1;
					if(fuelType == 0 && isEnergyStar == false) { //Standard Electric
						wattage = pDI.applianceProbDistrib[i][10][incomeLevelNumValue][0];
					}else if (fuelType == 0 && isEnergyStar == true) { //ES Electric
						wattage = pDI.applianceProbDistrib[i][10][incomeLevelNumValue][1];
					}else if (fuelType == 1 && isEnergyStar == false) { //Standard Gas
						wattage = pDI.applianceProbDistrib[i][10][incomeLevelNumValue][2];
					}else if (fuelType == 1 && isEnergyStar == true) { //ES Gas
						wattage = pDI.applianceProbDistrib[i][10][incomeLevelNumValue][3];
					}
					System.out.println("\t\t#"+(j+1)+" Wattage: "+wattage);
					applianceWattagesStorage.add(wattage);
					
					//Write these constant characteristics to the appliance instance profile and model info document
					modelWriter.writeApplianceProfileIDF(applianceInstanceName,fuelType,wattage);
					
					//Schedule this appliance instance
					int[][] schedule;
					for (int k = 0; k < numberOfWeeks; k++) {
						//Create schedule for this week
						schedule = scheduleAppliance(pDI.applianceProbDistrib, i);
						//Write the week schedule to IDf file
						modelWriter.writeWeeklyApplianceScheduleIDF(schedule,k,applianceInstanceName,60/applianceTimeStep);
					}
					
					//Write annual schedule
					modelWriter.writeAnnualApplianceScheduleIDF(applianceInstanceName);
				}
				//Write appliance type to the info document
				infoWriter.writeApplianceProfileInfo(numberOfApplianceInstances,fuelType,applianceEnergyStarsStorage,applianceWattagesStorage);

			}
			infoWriter.append("\n");
			//================================================================================================================	
			
			//CLOSING FILE WRITERS ===========================================================================================
			modelWriter.close();
			//================================================================================================================
		}
		infoWriter.close();
		System.out.println("DONE WITH EVERYTHING");
	}
	
	private int[][] scheduleAppliance(double[][][][] applianceProbDistrib, int applianceType) {
		int[][] schedule = new int[7][applianceTimeStep*24];
		int numberOfRuns;
		ArrayList<Integer> daysRan = new ArrayList<Integer>();
		double[] durationType_Distrib = applianceProbDistrib[applianceType][0][getIncomeLevelNumValue(incomeLevel)];
		double[] durationOptions = applianceProbDistrib[applianceType][1][getIncomeLevelNumValue(incomeLevel)];
		double[] runPerWeekDistrib = applianceProbDistrib[applianceType][4][getIncomeLevelNumValue(incomeLevel)];
		double[] dayOfWeekDistrib = applianceProbDistrib[applianceType][5][getIncomeLevelNumValue(incomeLevel)];
		double[] weekDayDistrib = applianceProbDistrib[applianceType][6][getIncomeLevelNumValue(incomeLevel)];
		double[] weekEndDayDistrib = applianceProbDistrib[applianceType][7][getIncomeLevelNumValue(incomeLevel)];
		int selectedTimeSlot;
		boolean isOverlap;
		int duration; //duration in number of time steps
		
		//Clear out old schedule, just in case
		daysRan.clear();
		//Determine number of runs for this week
		numberOfRuns = selectWithProbDistrib(runPerWeekDistrib);
		//System.out.println("Number of Runs: "+numberOfRuns+"\n");
		if (numberOfRuns > 0) {
			//Determine which days the appliance is ran (0 = Sunday, and so on...)
			for(int i = 0; i < numberOfRuns; i++) {
				daysRan.add(selectWithProbDistrib(dayOfWeekDistrib));
			}
			//Determine what time the appliance is ran
			for(int i = 0; i < numberOfRuns; i++) {
				if(daysRan.get(i)==0||daysRan.get(i)==6) {selectedTimeSlot = selectWithProbDistrib(weekEndDayDistrib);
				}else {selectedTimeSlot = selectWithProbDistrib(weekDayDistrib);}
				
				//Get duration of the appliance
				duration = getApplianceDuration(durationType_Distrib,durationOptions,selectedTimeSlot);
				//System.out.println("Duration: "+duration);
				
				//Check that the appliance run won't get cut off by the end of the day
				if(selectedTimeSlot + (duration-1) < 24*applianceTimeStep){//checking if the appliance schedule gets cut off by the end of the day
	               //Check if appliance runs overlap
					isOverlap = false;
					for(int j = 0; j < duration; j++) {
						if(schedule[daysRan.get(i)][selectedTimeSlot+j]!=0) {isOverlap = true;}
					}
					if(isOverlap) {
						i=i-1; //if there is overlap, schedule this run again
					}else {
						for(int j = 0; j < duration; j++) { 
							schedule[daysRan.get(i)][selectedTimeSlot+j] = 1; //if no cut off or overlap, then time slot is selected
						}
					}
					
	            }else {i=i-1;} //if it gets cutoff, schedule this run again
				
			}
			
		}
		return schedule;
	}

	private int getApplianceDuration(double[] durationType_Distrib, double[] durationOptions, int timeSlot) {
		//returns duration in terms of number of appliance time steps
		int duration = -1;
		
		if(durationType_Distrib[0] == 1) { //constant duration value, not dependent on anything else
			duration = (int)durationOptions[0];
		}else if(durationType_Distrib[0] < 0) {//meal-time specific duration
            if(timeSlot>=3 && timeSlot<=11){ //breakfast
                duration = (int)durationOptions[0];
            }else if(timeSlot>11 && timeSlot <= 16){ //lunch
                duration = (int)durationOptions[1];
            }else if((timeSlot>16 && timeSlot<=24)||(timeSlot<3)){ //dinner
                duration = (int)durationOptions[2];
            }
		}else { //probability-based duration
			duration = (int) durationOptions[selectWithProbDistrib(durationType_Distrib)];
		}
		
		return duration;
	}
	
	private int selectWithProbDistrib(double[] probDistrib) {
		
		//setting up
		int selectedExpression = -1;
		double probLow = -1;
		double probHigh = 0;
		
		//generate random number and loop through prob distrib bounds
		double randomNumber = Math.random();
		//System.out.println("RANDOM: "+randomNumber);
		for(int i = 0; i < probDistrib.length;i++) {
			probLow = probHigh;
            probHigh = probLow + probDistrib[i];
            if(randomNumber >= probLow && randomNumber < probHigh){
                selectedExpression = i; //select once random number is within bounds
                break;
            }
            if(i == (probDistrib.length - 1)){System.out.println("No selection:\n "+Arrays.toString(probDistrib)+"\n"+Arrays.stream(probDistrib).sum());}
            
		}
		return selectedExpression;
	}

	private int getClimateZoneNumValue(String climateZone) {
		int zoneNum = -1;
		switch(climateZone) {
			case "1A-2A":
				zoneNum = 0;
	            break;
	        case "2B":
	        	zoneNum = 1;
	            break;
	        case "3A":
	        	zoneNum = 2;
	            break;
	        case "3B-4B":
	        	zoneNum = 3;
	            break;
	        case "3C":
	        	zoneNum = 4;
	            break;
	        case "4A":
	        	zoneNum = 5;
	            break;
	        case "4C":
	        	zoneNum = 6;
	            break;
	        case "5A":
	        	zoneNum = 7;
	            break;
	        case "5B-5C":
	        	zoneNum = 8;
	            break;
	        case "6A-6B":
	        	zoneNum = 9;
	            break;
	        case "7A-7B-7AK-8AK":
	        	zoneNum = 10;    
	            break;
		}
		return zoneNum;
	}
	
	private int getIncomeLevelNumValue(String incomeLevel) {
		int incomeNum = -1;
		switch(incomeLevel) {
			case "Low Income":
				incomeNum = 0;
	            break;
	        case "Low-Middle Income":
	        	incomeNum = 1;
	            break;
	        case "Middle Income":
	        	incomeNum = 2;
	            break;
	        case "Middle-High Income":
	        	incomeNum = 3;
	            break;
	        case "High Income":
	        	incomeNum = 4;
	            break;
		}
		return incomeNum;
	}
}
