import java.awt.EventQueue;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.border.Border;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JProgressBar;

public class ModelGenGUI extends JFrame {

	private JPanel contentPane;
	private JTextField modelNumBox;
	private String outputFileDirectory;
	private String incomeLevel;
	private String climateZone;
	private int numOfModels;
	private int numOfIncomeLevels  = 5;
	private String desiredUnits;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModelGenGUI frame = new ModelGenGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public ModelGenGUI() throws IOException {
		
		
		try {
            // Set System L&F
        UIManager.setLookAndFeel(
            UIManager.getSystemLookAndFeelClassName());
	    } 
	    catch (UnsupportedLookAndFeelException e) {
	       // handle exception
	    }
	    catch (ClassNotFoundException e) {
	       // handle exception
	    }
	    catch (InstantiationException e) {
	       // handle exception
	    }
	    catch (IllegalAccessException e) {
	       // handle exception
	    }

		setResizable(false);
		
		setTitle("Residential Household Energy Model Generator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 617, 470);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ImageIcon img = new ImageIcon("Images\\houseBuildIcon.png");
		setIconImage(img.getImage());
		
		final JComboBox climateZoneBox = new JComboBox();
		climateZoneBox.setBackground(new Color(255, 255, 255));
		climateZoneBox.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		climateZoneBox.setModel(new DefaultComboBoxModel(new String[] {"1A-2A", "2B", "3A", "3B-4B", "3C", "4A", "4C", "5A", "5B-5C", "6A-6B", "7A-7B-7AK-8AK"}));
		climateZoneBox.setBounds(242, 131, 200, 32);
		contentPane.add(climateZoneBox);
		
		JLabel mainHeader = new JLabel("Realistic, diverse, unique household energy models...");
		mainHeader.setFont(new Font("Yu Gothic", Font.PLAIN, 22));
		mainHeader.setBounds(10, 48, 570, 50);
		contentPane.add(mainHeader);
		
		JLabel mainHeader_1 = new JLabel("all with a click of a button");
		mainHeader_1.setHorizontalAlignment(SwingConstants.RIGHT);
		mainHeader_1.setFont(new Font("Yu Gothic", Font.PLAIN, 19));
		mainHeader_1.setBounds(20, 75, 570, 50);
		contentPane.add(mainHeader_1);
		
		JButton aboutProjButton = new JButton("About the Project");
		aboutProjButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(contentPane,
					    "The goal of this project is to provide an automated program which creates diverse and unique household\n"
					    + "energy models while still following trends found in real life. Much energy research is performed on a\n"
					    + "single general household model, but we believe that – given the wide variety and randomness found in the\n"
					    + "residential sector – one model doesn’t adequately represent real life and is not a sufficient testbed. We\n"
					    + "also believe in the importance of making it easy for researchers to model households of specific income\n"
					    + "levels and locations, as they are determining factors in characteristics which impact household energy\n"
					    + "consumption. Many fields of energy research – including energy equity – are dependent on having access to\n"
					    + "income & climate specific household models.\n"
					    + "\n"
					    + "In response, we created this program which utilizes data from national surveys to semi-randomly implement\n"
					    + "characteristics into each household model. The survey data provides the probabilities that a model\n"
					    + "exhibits a characteristic in a certain way, depending on its specified income level and location. For\n"
					    + "example, it provides the likelihoods that a middle-income house in US climate zone 1A has ‘one’, ‘two’,\n"
					    + "‘three,’ or ‘four’ stories. Random number generation is then used to select one of these options. This\n"
					    + "basic principle is applied to both constant household characteristics (eg. stories) and time-variable\n"
					    + "household behaviors (eg. when an appliance is used). Therefore, each household model is unique and\n"
					    + "consumes energy on a variable schedule, but overall patterns will still be maintained as more models are\n"
					    + "created. For more information on how our program works and ideas for how it could be used, please read\n"
					    + "our publication:\n"
					    + "          Covington H, Woo-Shem B, Wang C, Roth T, Nguyen C, Lee H. Stochastic Method for\n"
					    + "          Generating Residential Household Energy Models Of Varying Income Level And Climate\n"
					    + "          Zone For Testing Energy Fairness. In: ASME 17th International Conference on Energy\n"
					    + "          Sustainability. 2023.\n"
					    + "\n"
					    + "Our team consists of students and faculty from Santa Clara University (SCU) and researchers from the\n"
					    + "National Institute of Standards and Technology (NIST). We would like to acknowledge the support of NIST\n"
					    + "and internal funding from SCU.\n"
					    + "Official contribution of the National Institute of Standards and Technology; not subject to copyright in\n"
					    + "the United States. Certain commercial products are identified in order to adequately specify the\n"
					    + "procedure; this does not imply endorsement or recommendation by NIST, nor does it imply that such\n"
					    + "products are necessarily the best available for the purpose.\n"
					    + "\n"
					    + "Our program outputs models which are to be simulated in the EnergyPlus energy building simulation\n"
					    + "platform. For more information on EnergyPlus and how to use it, please visit: energyplus.net\n"
					    + "\n"
					    + "We utilize the Building Model Prototypes provided by the US Office of Energy Efficiency and\n"
					    + "Renewable Energy as base models for our program to build upon. For more information, visit:\n"
					    + "energycodes.gov/prototype-building-models\n",
					    "About the Project",
					    JOptionPane.PLAIN_MESSAGE);
			}
		});
		aboutProjButton.setBackground(new Color(255, 255, 255));
		aboutProjButton.setVerticalAlignment(SwingConstants.BOTTOM);
		aboutProjButton.setFont(new Font("Yu Gothic", Font.PLAIN, 11));
		aboutProjButton.setBounds(462, 11, 128, 32);
		contentPane.add(aboutProjButton);
		
		JLabel climatelbl = new JLabel("Climate Zone");
		climatelbl.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		climatelbl.setBounds(10, 122, 207, 50);
		contentPane.add(climatelbl);
		
		JButton climateHelpButton = new JButton("Help");
		climateHelpButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("Images\\ClimateZones.png");
				JOptionPane.showMessageDialog(contentPane,
					    "The climate zone distinctions are based on the International\n"
					    + "Energy Conservation Code (IECC) definition. Some zones were\n"
					    + "combined due to the availability of data used to make the\n"
					    + "models. Currently, only locations in the United States are\n"
					    + "supported.\n"
					    + ".\n"
					    + "Warning: Climate zone 7A-7B-7AK-8AK is currently not\n"
					    + "supported due to lack of data availability. We apologize for\n"
					    + "the inconvenience.",
					    "Climate Zone Help",
					    JOptionPane.PLAIN_MESSAGE, icon);
				
			}
		});
		climateHelpButton.setVerticalAlignment(SwingConstants.TOP);
		climateHelpButton.setBackground(new Color(255, 255, 255));
		climateHelpButton.setFont(new Font("Yu Gothic", Font.PLAIN, 11));
		climateHelpButton.setBounds(460, 135, 73, 23);
		contentPane.add(climateHelpButton);
		
		JLabel incomelbl = new JLabel("Income Level");
		incomelbl.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		incomelbl.setBounds(10, 169, 207, 50);
		contentPane.add(incomelbl);
		
		final JComboBox incomeLevelBox = new JComboBox();
		incomeLevelBox.setBackground(new Color(255, 255, 255));
		incomeLevelBox.setModel(new DefaultComboBoxModel(new String[] {"Low Income", "Low-Middle Income", "Middle Income", "Middle-High Income", "High Income"}));
		incomeLevelBox.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		incomeLevelBox.setBounds(242, 178, 200, 32);
		contentPane.add(incomeLevelBox);
		
		JButton incomeHelpButton = new JButton("Help");
		incomeHelpButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(contentPane,
					    "By selecting one of these 5 income level categories, the household model(s) will be generated using data\n"
					    + "collected from real households within the same income level & climate zone category. Household models\n"
					    + "do not currently contain income information. They only are meant to be representative of real households\n"
					    + "in the same income level with regard to characteristics which are relevant to energy consumption.\n"
					    + "\n"
					    + "To collect data for each income level, data from surveyed households (see “About the Project”) needed to\n"
					    + "be sorted into one of 5 income categories: ‘low’, ‘low-middle’, ‘middle’, ‘middle-high’, and ‘high’.\n"
					    + "During this sorting process, we considered both household annual income and factors which impact cost of\n"
					    + "living – specifically location and number of household members.\n"
					    + "\n"
					    + "The annual income was adjusted by the Regional Price Parity (RPP) of the surveyed household's area. The US\n"
					    + "Bureau of Economic Analysis provides this information. The RPP represents how expensive it is to live in an\n"
					    + "area, relative to the national average. Therefore, dividing annual income by the RPP presents the\n"
					    + "household’s buying power in terms of the national average.\n"
					    + "\n"
					    + "To account for the size of the surveyed household, the location-adjusted income is compared to the\n"
					    + "median income of same-sized US households. The ratio of these two values decides which income level a\n"
					    + "household is sorted into. These distinctions are provided by the Pew Research Center and are as follows:\n"
					    + "     Low: <50%\n"
					    + "     Low-Middle: 50-66%\n"
					    + "     Middle: 67-200%\n"
					    + "     Middle-High: 201-300%\n"
					    + "     High: >300%\n",
					    "Income Level Help",
					    JOptionPane.PLAIN_MESSAGE);
			}
		});
		incomeHelpButton.setVerticalAlignment(SwingConstants.TOP);
		incomeHelpButton.setBackground(new Color(255, 255, 255));
		incomeHelpButton.setFont(new Font("Yu Gothic", Font.PLAIN, 11));
		incomeHelpButton.setBounds(460, 186, 73, 23);
		contentPane.add(incomeHelpButton);
		
		JLabel houseNumlbl = new JLabel("Number of Models");
		houseNumlbl.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		houseNumlbl.setBounds(10, 216, 207, 50);
		contentPane.add(houseNumlbl);
		
		modelNumBox = new JTextField();
		modelNumBox.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		modelNumBox.setBounds(242, 227, 128, 29);
		contentPane.add(modelNumBox);
		modelNumBox.setColumns(10);
		
		JLabel houseNumlbl_1 = new JLabel("(All generated models will be of the");
		houseNumlbl_1.setFont(new Font("Yu Gothic", Font.PLAIN, 11));
		houseNumlbl_1.setBounds(380, 217, 210, 50);
		contentPane.add(houseNumlbl_1);
		
		JLabel fileLocationlbl = new JLabel("Output File(s) Location");
		fileLocationlbl.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		fileLocationlbl.setBounds(10, 263, 222, 50);
		contentPane.add(fileLocationlbl);
		
		JLabel unitslbl = new JLabel("Units of EnergyPlus Output");
		unitslbl.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		unitslbl.setBounds(10, 310, 222, 50);
		contentPane.add(unitslbl);
		
		final JComboBox unitsBox = new JComboBox();
		unitsBox.setModel(new DefaultComboBoxModel(new String[] {"Joule (J)", "Kilowatt-hour (kWh)", "Inch-Pound Units (IP)"}));
		unitsBox.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		unitsBox.setBackground(Color.WHITE);
		unitsBox.setBounds(242, 319, 200, 32);
		contentPane.add(unitsBox);
		
		final JLabel warninglbl = new JLabel("");
		warninglbl.setForeground(new Color(255, 0, 0));
		warninglbl.setFont(new Font("Yu Gothic", Font.PLAIN, 12));
		warninglbl.setBounds(20, 370, 422, 27);
		contentPane.add(warninglbl);
		
		final JLabel outputFileWarning = new JLabel("No output directory currently selected");
		outputFileWarning.setForeground(new Color(0, 0, 0));
		outputFileWarning.setFont(new Font("Yu Gothic", Font.PLAIN, 11));
		outputFileWarning.setBounds(351, 264, 210, 50);
		contentPane.add(outputFileWarning);
		
		JButton folderDirButton = new JButton("Browse");
		folderDirButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new java.io.File("."));
			    chooser.setDialogTitle("Pick Output File Destination");
			    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			    chooser.setAcceptAllFileFilterUsed(false);
			    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			        outputFileDirectory = String.valueOf(chooser.getSelectedFile());
			        System.out.println(outputFileDirectory);
					outputFileWarning.setText("");
					warninglbl.setText("");
			    }else {
			        System.out.println("No Selection ");
			        warninglbl.setText("Warning: No output directory selected");
			    }
			}
		});
		folderDirButton.setVerticalAlignment(SwingConstants.TOP);
		folderDirButton.setBackground(new Color(255, 255, 255));
		folderDirButton.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		folderDirButton.setBounds(242, 271, 99, 29);
		contentPane.add(folderDirButton);
		
		final JButton generateButton = new JButton("Generate");
		generateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				warninglbl.setText("");
				try {
					if(Integer.parseInt(modelNumBox.getText())<0){
						warninglbl.setText("Error: Number of models must be a nonzero, positive integer");
						numOfModels = -1;
					}else {
						numOfModels = Integer.parseInt(modelNumBox.getText());
					}
				}catch(NumberFormatException formatError){
					warninglbl.setText("Error: Number of models must be a nonzero, positive integer");
					numOfModels = 0;
				}
				
				if(outputFileDirectory == null){warninglbl.setText("Error: No directory selected for output files");}
				
				incomeLevel = incomeLevelBox.getSelectedItem().toString();
				climateZone = climateZoneBox.getSelectedItem().toString();
				desiredUnits = unitsBox.getSelectedItem().toString();
				System.out.println("Number of Models: "+numOfModels);
				System.out.println("Income Level: "+incomeLevel);
				System.out.println("Climate Zone: "+climateZone);
				System.out.println("Desired Units: "+desiredUnits);
				try {
					if(numOfModels != 0) {
					ModelGenerator modelGen = new ModelGenerator(outputFileDirectory, incomeLevel, climateZone, numOfModels, numOfIncomeLevels, desiredUnits);
					JOptionPane.showMessageDialog(contentPane,
						    "Model generation has completed.",
						    "Model Generator Message",
						    JOptionPane.PLAIN_MESSAGE);
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		generateButton.setVerticalAlignment(SwingConstants.TOP);
		generateButton.setFont(new Font("Yu Gothic", Font.PLAIN, 16));
		generateButton.setBounds(452, 368, 128, 29);
		contentPane.add(generateButton);
		
		JLabel houseNumlbl_1_1 = new JLabel("selected climate zone and income level)");
		houseNumlbl_1_1.setFont(new Font("Yu Gothic", Font.PLAIN, 11));
		houseNumlbl_1_1.setBounds(385, 233, 215, 50);
		contentPane.add(houseNumlbl_1_1);
		
		JButton requirementButton = new JButton("System Requirements");
		requirementButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(contentPane,
					    "This model generation program requires than a Java Runtime Environment (JRE) be installed on the computer.\n"
					    + "Please visit java.com/download to install the newest version of java.\n"
					    + "\n"
					    + "The model files are to be simulated in EnergyPlus v9.4.0. If you are running a newer version of EnergyPlus,\n"
					    + "you may need to update the model files using EnergyPlus' IDFVersionUpdater functionality. This can be\n"
					    + "time-consuming, so it is recommended that you install v9.4.0.\n"
					    + "EnergyPlus offers various versions of their software for download at: energyplus.net/downloads.",
					    "Income Level Help",
					    JOptionPane.PLAIN_MESSAGE);
			}
		});
		requirementButton.setVerticalAlignment(SwingConstants.BOTTOM);
		requirementButton.setFont(new Font("Yu Gothic", Font.PLAIN, 11));
		requirementButton.setBackground(Color.WHITE);
		requirementButton.setBounds(293, 11, 147, 32);
		contentPane.add(requirementButton);
		
		
		/*
		int logoDimensions = 50;
		
		ImageIcon scuLogo =  new ImageIcon("Images\\SCULogo.jpeg");
		Image scuLogoImage = scuLogo.getImage();
		Image scaledScuLogo = scuLogoImage.getScaledInstance(logoDimensions, logoDimensions, Image.SCALE_SMOOTH);
		scuLogo = new ImageIcon(scaledScuLogo);
		JLabel scuLogoPanel = new JLabel("");
		scuLogoPanel.setIcon(scuLogo);
		scuLogoPanel.setBounds(462, 408, 55, 46);
		contentPane.add(scuLogoPanel);
		

		ImageIcon nistLogo = new ImageIcon("Images\\NISTlogo.png");
		Image nistLogoImage = nistLogo.getImage();
		Image scaledNistLogo = nistLogoImage.getScaledInstance(logoDimensions, logoDimensions, java.awt.Image.SCALE_SMOOTH);
		nistLogo = new ImageIcon(scaledNistLogo);
		JLabel nistLogoPanel = new JLabel("");
		nistLogoPanel.setIcon(nistLogo);
		nistLogoPanel.setBounds(565, 415, logoDimensions, logoDimensions);
		contentPane.add(nistLogoPanel);
		*/
		
		JLabel houseNumlbl_1_2 = new JLabel("A collaboration of Santa Clara University (SCU) and the National Institute of Standards and Technology (NIST)");
		houseNumlbl_1_2.setFont(new Font("Yu Gothic", Font.PLAIN, 11));
		houseNumlbl_1_2.setBounds(10, 408, 590, 32);
		contentPane.add(houseNumlbl_1_2);
		
		
		
	}
}
