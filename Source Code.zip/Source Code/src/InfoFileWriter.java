import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class InfoFileWriter {
	
	//Initializing FileWriter which is used throughout the Class
	FileWriter infoFile;
	
	////Declaring how different characteristics may be expressed. 
	//IF CHANGED HERE, MUST ALSO BE CHANGED IN MODELFILEWRITER.JAVA TO TAKE EFFECT IN THE MODELS THEMSELVES
	String[] insulationOptions = {"Well","Adequate","Poor","Not"};
	String[] draftOptions = {"Always","Mostly","Sometimes","Never"};
	int[] sqftOptions = {500,1500,2500,3500,4500,5500,6500,7500,8500};
	//String[] heatingTypeOptions = {"HOTWATER","CENTRAL","HEATPUMP","INSTALLEDELECTRIC","BUILTIN PIPELESS","BUILTIN BURNING","WOODBURNING","FIREPLACE","PORTABLE ELEC"};
	String[] heatingTypeOptions = {"Central","Central","Heat Pump","Central","Central","Central","Central","Central","Central"};
	//String[] heatingFuelOptions = {"NAT.GAS","PROPANE","OIL","ELEC","WOOD"};
	String[] heatingFuelOptions = {"Gas","Gas","Oil","Electric","Oil"};
	String[] coolingTypeOptions = {"Central","Individual"};
	String[] waterHeaterSizeOptions = {"Small","Medium","Large","Tankless"};
	String[] ageOptions = {"<2 Years","2-4 Years","5-9 Years","10-14 Years","15-19 Years","20+ Years"};
	String[] waterHeaterFuelOptions = {"Gas","Electric"};
	double[] windowPerSqftOptions = {136.8e-5,295e-5,453e-5,611e-5,769e-5,929e-5,1087e-5,1243e-5,1401e-5,1559e-5,1638e-5};
	double[] bedroomsPerSqftOptions = {15e-5,45e-5,75e-5,105e-5,135e-5,165e-5,195e-5,225e-5,255e-5,285e-5,300e-5};
	double[] bathroomsPerSqftOptions = {12e-5,36e-5,60e-5,84e-5,108e-5,132e-5,156e-5,180e-5,204e-5,228e-5,240e-5};
	double[] lightingPerSqftOptions = {5.63e-2,9.63e-2,17.63e-2,25.63e-2,33.63e-2,41.63e-2,49.63e-2,57.63e-2,65.63e-2,73.63e-2,81.63e-2,85.63e-2};
	double[] miscPerSqftOptions = {6.49e-2,10.99e-2,19.99e-2,28.99e-2,37.99e-2,46.99e-2,55.99e-2,64.99e-2,73.99e-2,82.99e-2,91.99e-2,100.99e-2,105.49e-2};
	String[] fridgeDoorOptions = {"One","Two(FreezerNext)","Two(FreezerAbove)","Two(FreezerBelow","Three+"};
	
	String[] fridgeSizeOptions = {"Compact","Small","Medium","Large","VeryLarge"};
	
	public InfoFileWriter(String fileName) throws IOException {
		infoFile = new FileWriter(fileName);
	}
	
	public void writeInfoHeader() throws IOException {
		infoFile.append("Income,Climate,HouseNumber,Stories,Window Area [m],Insulation,Draftiness,Square Footage,Heat Used?,Heating Type,Heating Fuel,Cooling Used?,Cooling Type,Num of Members, Cooling Setpoint [F],Heating Setpoint [F],Water Heater Size,Water Heater Age,Water Heater Fuel,Water Heater ES?,Num of Bedrooms, Num of Bathrooms, Lighting Annual kWh, Misc Annual kWh,Num of Fridges,Fridge ES?,Fridge Arragement,Fridge Age,Fridge Size,Dishwasher?,Dishwasher Fuel,Dishwasher ES?,Dishwasher Wattage,Clotheswasher?,Clotheswasher Fuel,Clotheswasher ES?,Clotheswasher Wattage,Clothesdryer?,Clothesdryer Fuel,Clothesdryer ES?,Clothesdryer Wattage, Num of Cooktops,Cooktop Fuel,Cooktop ES?,Cooktop Wattage,Num of Ovens,Oven Fuel,Oven ES?,Oven Wattage\n");
	}
	
	public void append(String stringToAppend) throws IOException {
		infoFile.append(stringToAppend);
	}
	
	public void close() throws IOException {
		infoFile.close();
	}
	
	public void writeConstantCharInfo(int[] selectedExpressions) throws IOException {
		//Number of Stories
		infoFile.append((selectedExpressions[0]+1)+",");
		//Window Area
		infoFile.append(sqftOptions[selectedExpressions[4]]*windowPerSqftOptions[selectedExpressions[1]]+",");
		//Insulation Level
		infoFile.append((insulationOptions[selectedExpressions[2]])+",");
		//Draft Level
		infoFile.append(draftOptions[selectedExpressions[3]]+",");
		//Total Square Feet
		infoFile.append(sqftOptions[selectedExpressions[4]]+",");
		//Is Heating Used?
		infoFile.append(selectedExpressions[5]+",");
		//Type of Heating
		infoFile.append(heatingTypeOptions[selectedExpressions[6]]+",");
		//Type of Heating Fuel
		infoFile.append(heatingFuelOptions[selectedExpressions[7]]+",");
		//Is Cooling Used?
		infoFile.append(selectedExpressions[8]+",");
		//Type of Cooling Used
		infoFile.append(coolingTypeOptions[selectedExpressions[9]]+",");
		//Number of Members
		infoFile.append((selectedExpressions[10]+1)+",");
		//Cooling Set Point
		infoFile.append((selectedExpressions[11]+50)+",");
		//Heating Set Point
		infoFile.append((selectedExpressions[12]+50)+",");
		//Water Heater Size
		infoFile.append(waterHeaterSizeOptions[selectedExpressions[13]]+",");
		//Water Heater Age
		infoFile.append(ageOptions[selectedExpressions[14]]+",");
		//Water Heater Fuel
		infoFile.append(waterHeaterFuelOptions[selectedExpressions[15]]+",");
		//Water Heater Energy Star?
		infoFile.append(selectedExpressions[16]+",");
		//Number of Bedrooms
		infoFile.append(Math.ceil(bedroomsPerSqftOptions[selectedExpressions[17]]*sqftOptions[selectedExpressions[4]])+",");
		//Number of Bathrooms
		infoFile.append(Math.ceil(bathroomsPerSqftOptions[selectedExpressions[18]]*sqftOptions[selectedExpressions[4]])+",");
		//Lighting Wattage
		infoFile.append(sqftOptions[selectedExpressions[4]]*lightingPerSqftOptions[selectedExpressions[19]]+",");
		//Miscellaneous Wattage
		infoFile.append(sqftOptions[selectedExpressions[4]]*miscPerSqftOptions[selectedExpressions[20]]+",");
		
	}
	
	public void writeFridgeCharInfo(int numberOfFridges, int[][] selectedExpressions) throws IOException {
		//Energy Star?
		for(int i = 0; i < numberOfFridges; i++) {
			infoFile.append(selectedExpressions[i][0]+" ");
			if(i<numberOfFridges-1) {infoFile.append("| ");}
		}
		infoFile.append(",");
		
		//Door arrangement
		for(int i = 0; i < numberOfFridges; i++) {
			infoFile.append(fridgeDoorOptions[selectedExpressions[i][1]]+" | ");
			if(i<numberOfFridges-1) {infoFile.append("| ");}
		}
		infoFile.append(",");
		
		//Age
		for(int i = 0; i < numberOfFridges; i++) {
			infoFile.append(ageOptions[selectedExpressions[i][2]]+" ");
			if(i<numberOfFridges-1) {infoFile.append("| ");}
		}
		infoFile.append(",");
		
		//Size
		for(int i = 0; i < numberOfFridges; i++) {
			infoFile.append(fridgeSizeOptions[selectedExpressions[i][3]]+" ");
			if(i<numberOfFridges-1) {infoFile.append("| ");}
		}
		infoFile.append(",");
	}
	
	public void writeApplianceProfileInfo(int numberOfApplianceInstances, int fuelType, ArrayList<Boolean> energyPlusInfo, ArrayList<Double> wattages) throws IOException {
		//Number of appliance type
		infoFile.append(numberOfApplianceInstances+",");
		
		//Fuel type of appliance
		if(numberOfApplianceInstances==0){infoFile.append("NA,");
		}else if(fuelType == 0) {infoFile.append("Electric,");
		}else {infoFile.append("Gas,");}
		
		//EnergyPlus certifications for each instance
		if(numberOfApplianceInstances==0){infoFile.append("NA,");
		}else {
			for(int i = 0 ; i < numberOfApplianceInstances ; i++) {
				infoFile.append(energyPlusInfo.get(i)+"");
				if(i<numberOfApplianceInstances-1) {infoFile.append("| ");}
			}
			infoFile.append(",");
		}
		
		//Wattages for each instance
		if(numberOfApplianceInstances==0){infoFile.append("NA,");
		}else {
			for(int i = 0 ; i < numberOfApplianceInstances ; i++) {
				infoFile.append(wattages.get(i)+" ");
				if(i<numberOfApplianceInstances-1) {infoFile.append("| ");}
			}
			infoFile.append(",");
		}
	}
}
