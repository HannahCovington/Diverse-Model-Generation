import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

public class ModelFileWriter {
	
	//Initializing variables used throughout the Class
	FileWriter FW;
	int[] selectedExpressions;
	private double Xmax = -1;
	private double Ymax = -1;
	private double houseHeight = -1;
	private String fuelH2O = "";
	boolean isTankless;
	String cycleType;
	double tankVolume;
	boolean isESQual;
	double efficiency;
	int numberOfBedrooms;
	int numberOfBathrooms;
	String outputFileName;
	
	//Declaring how different characteristics may be expressed. Can be adjusted if needed. (getWaterHeaterCharacteristics also contains variables which can be adjusted)
	//If you change a variable here, remember to change it in InfoFileWriter.java as well, so the changes are reflected in info file
	double[] squareMeterOptions = {46.45,139.35,232.26,325.16,418.06,510.97,603.87,696.77,789.68};
	double metersPerStory = 2.7432; // assuming 9 feet per story
	double roofHeight = 1.52;
	int[] sqftOptions = {500,1500,2500,3500,4500,5500,6500,7500,8500};
	double[] windowPerSqftOptions = {136.8e-5,295e-5,453e-5,611e-5,769e-5,929e-5,1087e-5,1243e-5,1401e-5,1559e-5,1638e-5};
	double minimumDistanceFromWindowToWallEdge = 0.25; //meters
	double[] draftOptions = {2.75,2.2,.825,.275};
	double[] recommendedAtticInsulOptions = {39.5,39.5,45,45,45,49,49,49,49,54.5,54.5}; //R value from ES
	double[] recommendedWallInsulOptions = {14,14,14,14,14,14,14,14,14,14,14}; //R value from ES
	double[] recommendedFloorInsulOptions = {13,13,25,25,25,27.5,27.5,27.5,27.5,27.5,27.5}; //R value from ES
	double[] percentOfRecOptions = {1,.75,.25,0};//for insulation
	String[] waterHeaterFuelOptions = {"NaturalGas","Electricity"};
	double[] bedroomsPerSqftOptions = {15e-5,45e-5,75e-5,105e-5,135e-5,165e-5,195e-5,225e-5,255e-5,285e-5,300e-5};
	double[] bathroomsPerSqftOptions = {12e-5,36e-5,60e-5,84e-5,108e-5,132e-5,156e-5,180e-5,204e-5,228e-5,240e-5};
	double[] lightingPerSqftOptions = {5.63e-2,9.63e-2,17.63e-2,25.63e-2,33.63e-2,41.63e-2,49.63e-2,57.63e-2,65.63e-2,73.63e-2,81.63e-2,85.63e-2};
	double[] miscPerSqftOptions = {6.49e-2,10.99e-2,19.99e-2,28.99e-2,37.99e-2,46.99e-2,55.99e-2,64.99e-2,73.99e-2,82.99e-2,91.99e-2,100.99e-2,105.49e-2};

	public ModelFileWriter(String oFN) throws IOException{
		outputFileName = oFN;
	}
	
	public void copyOverSkeletonModel(int heatingType, int heatingFuel, String climateZone) throws IOException {
		//Get the directory to the file you want to copy over. Depends on climate zone
		String copyFileDirectory = "Data\\BaseModelFiles\\EnergyPlus_"+climateZone+"_2018_IECC\\";
		
		//The file name of the appropriate skeleton model depends on heating type/fuel
		String heatEquipString = null;
		if(heatingType == 2) {heatEquipString = "hp";}
		else if(heatingFuel == 0 || heatingFuel == 1) {heatEquipString = "gasfurnace";}
		else if(heatingFuel == 2 || heatingFuel == 4) {heatEquipString = "oilfurnace";}
		else if(heatingFuel == 3) {heatEquipString = "elecres";}
		
		String copyFileName = copyFileDirectory;
		switch(climateZone) {
			case "1A-2A": copyFileName += "SF+CZ1A+USA_FL_Miami.Intl.AP.722020+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "2B":copyFileName += "SF+CZ2B+USA_AZ_Phoenix-Sky.Harbor.Intl.AP.722780+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "3A":copyFileName += "SF+CZ3A+USA_TN_Memphis.Intl.AP.723340+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "3B-4B":copyFileName += "SF+CZ3B+USA_TX_El.Paso.Intl.AP.722700+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "3C":copyFileName += "SF+CZ3C+USA_CA_San.Francisco.Intl.AP.724940+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "4A":copyFileName += "SF+CZ4A+USA_MD_Baltimore-Washington.Intl.AP.724060+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "4C":copyFileName += "SF+CZ4C+USA_OR_Salem-McNary.Field.726940+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "5A":copyFileName += "SF+CZ5A+USA_IL_Chicago-OHare.Intl.AP.725300+"+heatEquipString+"+slab+IECC_2018.idf";;break;
			case "5B-5C":copyFileName += "SF+CZ5B+USA_ID_Boise.Air.Terminal.726810+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "6A-6B":copyFileName += "SF+CZ6A+USA_VT_Burlington.Intl.AP.726170+"+heatEquipString+"+slab+IECC_2018.idf";break;
			case "7A-7B-7AK-8AK":copyFileName += "SF+CZ8+USA_AK_Fairbanks.Intl.AP.702610+"+heatEquipString+"+slab+IECC_2018.idf";break;
		}
		
		//Now actually copy stuff over
		InputStream is = null;
        OutputStream os = null;
        try {
            is = new FileInputStream(copyFileName);
            os = new FileOutputStream(outputFileName);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        } finally {
            is.close();
            os.close();
        }
        
        FW = new FileWriter(outputFileName,true);
	}
	
	public void writeConstantCharIDF(int[] selectedExpressions, String modelFileName, int climateZoneNumValue, int timeStep, String desiredUnits) throws IOException {
		writeBuildingShape(selectedExpressions);
		writeWindows(selectedExpressions);
		writeDraftiness(selectedExpressions);
		writeInsulation(selectedExpressions, climateZoneNumValue);
		writeThermostatBaseline(selectedExpressions);
		writeTimeStep(timeStep);
		writeUnits(desiredUnits);
		writeWaterHeater(selectedExpressions);
		writeNumberOfMembers(selectedExpressions);
		writeThermostatSetpoints(selectedExpressions);
		writeLighting(selectedExpressions);
		writeMiscLoads(selectedExpressions);
	}
	public void writeUnits(String desiredUnits) throws IOException {
		String unitConversion = "";
		
		switch(desiredUnits){
			case "Inch-Pound Units (IP)": unitConversion = "InchPound"; break;
			case "Joule (J)": unitConversion = "None"; break;
			case "Kilowatt-hour (kWh)": unitConversion = "JtoKWH"; break;
			case "Megajoule (MJ)": unitConversion = "JtoMJ"; break;
			case "Gigajoule (GJ)": unitConversion = "JtoGJ"; break;
		}
		
		FW.append("OutputControl:Table:Style,\n");
		FW.append("\tCommaAndHTML,            !- Column Separator\n");
		FW.append("\t"+unitConversion+";               !- Unit Conversion\n\n");
	}
	
	public void writeWeeklyApplianceScheduleIDF(int[][] schedule, int weekNumber, String applianceName, int timeStepAppliance) throws IOException {
		//Write daily schedules first
		boolean[] isOffDay = {false,false,false,false,false,false,false};
		for(int i = 0; i<7; i++) {
			if(Arrays.stream(schedule[i]).sum() == 0) { //If the appliance isn't used this week, use pre-made Off schedule
				isOffDay[i] = true;
			}else {
				writeDaySchedule(weekNumber,i,schedule[i], applianceName, timeStepAppliance);
			}
		}
		//Write week schedule
		writeWeekSchedule(isOffDay, weekNumber, applianceName);
	}
	
	private void writeDaySchedule(int weekNumber, int day, int[] daySchedule, String applianceName, int timeStepAppliance) throws IOException {
		int nValue = 3;
        FW.append("\nSchedule:Day:List,\n");
        FW.append("\tWeek"+weekNumber+"Day"+day+applianceName+"Sch,\t\t!- Name\n");
        FW.append("\tfraction,\t\t!- Schedule Type Limits Name\n");
        FW.append("\tNo,\t\t!- Interpolate to Timestep\n");
        FW.append("\t"+timeStepAppliance+",\t\t!- Minutes per Item\n");
        FW.append("\t"+daySchedule[0]+",\t\t!- Value 1\n");
        for(int i = 1;i<(daySchedule.length-1);i++){
            FW.append("\t"+daySchedule[i]+",\t\t!- N" + nValue + "\n");
            nValue++;
        }
        FW.append("\t"+daySchedule[daySchedule.length-1]+";\t\t!- N" + nValue + "\n");
	}
	
	private void writeWeekSchedule(boolean[] offDayInfo, int weekNumber, String applianceName) throws IOException {
		FW.append("\nSchedule:Week:Daily,\n");
        FW.append("\tWeek"+weekNumber+applianceName+"Sch,\t\t!- Name\n");
        //writing regular week days
        for(int i = 0; i < 7;i++){
            //get schedule value
            if(offDayInfo[i]==true){
                FW.append("\talwaysOffDaySch,");
            }else{
                FW.append("\tWeek"+weekNumber+"Day"+i+applianceName+"Sch,");
            }
                //write appropriate descriptive comment
            switch(i){
                case 0: FW.append("\t\t!- Sunday Schedule:Day Name\n"); break;
                case 1: FW.append("\t\t!- Monday Schedule:Day Name\n"); break;
                case 2: FW.append("\t\t!- Tuesday Schedule:Day Name\n"); break;
                case 3: FW.append("\t\t!- Wednesday Schedule:Day Name\n"); break;
                case 4: FW.append("\t\t!- Thursday Schedule:Day Name\n"); break;
                case 5: FW.append("\t\t!- Friday Schedule:Day Name\n"); break;
                case 6: FW.append("\t\t!- Saturday Schedule:Day Name\n");break;
            }
        }
        //writing special days (*NOTE: set holiday, summer design day, and winter design day to always off)
        FW.append("\talwaysOffDaySch,\t\t!- Holiday Schedule:Day Name\n");
        FW.append("\talwaysOffDaySch,\t\t!- SummerDesignDay Schedule:Day Name\n");
        FW.append("\talwaysOffDaySch,\t\t!- WinterDesignDay Schedule:Day Name\n");
        FW.append("\talwaysOffDaySch,\t\t!- CustomDay1 Schedule:Day Name\n");
        FW.append("\talwaysOffDaySch;\t\t!- CustomDay2 Schedule:Day Name\n");
	}
	
	private int getMonthLength(int month){
        int numDays;
        switch(month){
            case 1: case 3: case 5: case 7: case 8: case 10: case 12: numDays = 31; break;
            case 2: numDays = 28; break;
            case 4: case 6: case 9: case 11: numDays = 30; break;
            default: numDays = -1;
        }
        return numDays;
    }
		
	private void writeBuildingShape(int[] selectedExpressions) throws IOException {
		//Note: we switch to square meters instead of square feet because E+ measures in meters
		
		//Retrieving Relevant Variables
		int numberOfStories = selectedExpressions[0]+1;
		double squareMeterPerStory = squareMeterOptions[selectedExpressions[4]]/numberOfStories;
		//Calculating Variables
		Xmax = Math.sqrt(squareMeterPerStory);
		Ymax = Math.sqrt(squareMeterPerStory);
		houseHeight = metersPerStory*numberOfStories;
		
		//Writing Ceiling to IDF
        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tceiling_unit1,           !- Name\n");
        FW.append("\tCeiling,                 !- Surface Type\n");
        FW.append("\tInterior Ceiling,        !- Construction Name\n");
        FW.append("\tliving_unit1,            !- Zone Name\n");
        FW.append("\tZone,                    !- Outside Boundary Condition\n");
        FW.append("\tattic_unit1,             !- Outside Boundary Condition Object\n");
        FW.append("\tNoSun,                   !- Sun Exposure\n");
        FW.append("\tNoWind,                  !- Wind Exposure\n");
        FW.append("\t0.0,                     !- View Factor to Ground\n");
        FW.append("\t4,                       !- Number of Vertices\n");
        FW.append("\t0,                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 3 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",        !- Vertex 3 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 3 Z-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+";        !- Vertex 4 Z-coordinate {m}\n\n");
        
        //Writing Roof to IDF
        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tRoof_front_unit1,        !- Name\n");
        FW.append("\tRoof,                    !- Surface Type\n");
        FW.append("\tExterior Roof,           !- Construction Name\n");
        FW.append("\tattic_unit1,             !- Zone Name\n");
        FW.append("\tOutdoors,                !- Outside Boundary Condition\n");
        FW.append("\t,                        !- Outside Boundary Condition Object\n");
        FW.append("\tSunExposed,              !- Sun Exposure\n");
        FW.append("\tWindExposed,             !- Wind Exposure\n");
        FW.append("\t0.0,                     !- View Factor to Ground\n");
        FW.append("\t4,                       !- Number of Vertices\n");
        FW.append("\t0,                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 3 X-coordinate {m}\n");
        FW.append("\t"+(Ymax/2)+",        !- Vertex 3 Y-coordinate {m}\n");
        FW.append("\t"+(houseHeight+roofHeight)+",        !- Vertex 3 Z-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t"+(Ymax/2)+",        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+(houseHeight+roofHeight)+";        !- Vertex 4 Z-coordinate {m}\n\n");
        
        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tRoof_back_unit1,         !- Name\n");
        FW.append("\tRoof,                    !- Surface Type\n");
        FW.append("\tExterior Roof,           !- Construction Name\n");
        FW.append("\tattic_unit1,             !- Zone Name\n");
        FW.append("\tOutdoors,                !- Outside Boundary Condition\n");
        FW.append("\t,                        !- Outside Boundary Condition Object\n");
        FW.append("\tSunExposed,              !- Sun Exposure\n");
        FW.append("\tWindExposed,             !- Wind Exposure\n");
        FW.append("\t0.0,                     !- View Factor to Ground\n");
        FW.append("\t4,                       !- Number of Vertices\n");
        FW.append("\t"+Xmax+",                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 3 X-coordinate {m}\n");
        FW.append("\t"+(Ymax/2)+",        !- Vertex 3 Y-coordinate {m}\n");
        FW.append("\t"+(houseHeight+roofHeight)+",        !- Vertex 3 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t"+(Ymax/2)+",        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+(houseHeight+roofHeight)+";        !- Vertex 4 Z-coordinate {m}\n\n");

        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tRoof_right_unit1,        !- Name\n");
        FW.append("\tWall,                    !- Surface Type\n");
        FW.append("\tGable_end,               !- Construction Name\n");
        FW.append("\tattic_unit1,             !- Zone Name\n");
        FW.append("\tOutdoors,                !- Outside Boundary Condition\n");
        FW.append("\t,                        !- Outside Boundary Condition Object\n");
        FW.append("\tSunExposed,              !- Sun Exposure\n");
        FW.append("\tWindExposed,             !- Wind Exposure\n");
        FW.append("\t,                     !- View Factor to Ground\n");
        FW.append("\t3,                       !- Number of Vertices\n");
        FW.append("\t"+Xmax+",                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t"+(Ymax/2)+",        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+(houseHeight+roofHeight)+";        !- Vertex 4 Z-coordinate {m}\n\n");
    
        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tRoof_left_unit1,         !- Name\n");
        FW.append("\tWall,                    !- Surface Type\n");
        FW.append("\tGable_end,               !- Construction Name\n");
        FW.append("\tattic_unit1,             !- Zone Name\n");
        FW.append("\tOutdoors,                !- Outside Boundary Condition\n");
        FW.append("\t,                        !- Outside Boundary Condition Object\n");
        FW.append("\tSunExposed,              !- Sun Exposure\n");
        FW.append("\tWindExposed,             !- Wind Exposure\n");
        FW.append("\t,                     !- View Factor to Ground\n");
        FW.append("\t3,                       !- Number of Vertices\n");
        FW.append("\t0,                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t"+(Ymax/2)+",        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+(houseHeight+roofHeight)+";        !- Vertex 4 Z-coordinate {m}\n\n");

        //Writing Walls to IDF
        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tWall_ldf_1.unit1,        !- Name\n");
        FW.append("\tWall,                    !- Surface Type\n");
        FW.append("\tExterior Wall,           !- Construction Name\n");
        FW.append("\tliving_unit1,            !- Zone Name\n");
        FW.append("\tOutdoors,                !- Outside Boundary Condition\n");
        FW.append("\t,                        !- Outside Boundary Condition Object\n");
        FW.append("\tSunExposed,              !- Sun Exposure\n");
        FW.append("\tWindExposed,             !- Wind Exposure\n");
        FW.append("\t,                     !- View Factor to Ground\n");
        FW.append("\t4,                       !- Number of Vertices\n");
        FW.append("\t0,                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 3 X-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 3 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 3 Z-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+";        !- Vertex 4 Z-coordinate {m}\n\n");

        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tWall_sdr_1.unit1,        !- Name\n");
        FW.append("\tWall,                    !- Surface Type\n");
        FW.append("\tExterior Wall,           !- Construction Name\n");
        FW.append("\tliving_unit1,            !- Zone Name\n");
        FW.append("\tOutdoors,                !- Outside Boundary Condition\n");
        FW.append("\t,                        !- Outside Boundary Condition Object\n");
        FW.append("\tSunExposed,              !- Sun Exposure\n");
        FW.append("\tWindExposed,             !- Wind Exposure\n");
        FW.append("\t,                     !- View Factor to Ground\n");
        FW.append("\t4,                       !- Number of Vertices\n");
        FW.append("\t"+Xmax+",                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 3 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",        !- Vertex 3 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 3 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+";        !- Vertex 4 Z-coordinate {m}\n\n");

        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tWall_ldb_1.unit1,        !- Name\n");
        FW.append("\tWall,                    !- Surface Type\n");
        FW.append("\tExterior Wall,           !- Construction Name\n");
        FW.append("\tliving_unit1,            !- Zone Name\n");
        FW.append("\tOutdoors,                !- Outside Boundary Condition\n");
        FW.append("\t,                        !- Outside Boundary Condition Object\n");
        FW.append("\tSunExposed,              !- Sun Exposure\n");
        FW.append("\tWindExposed,             !- Wind Exposure\n");
        FW.append("\t,                     !- View Factor to Ground\n");
        FW.append("\t4,                       !- Number of Vertices\n");
        FW.append("\t"+Xmax+",                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 3 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",        !- Vertex 3 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 3 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+";        !- Vertex 4 Z-coordinate {m}\n\n");

        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tWall_sdl_1.unit1,        !- Name\n");
        FW.append("\tWall,                    !- Surface Type\n");
        FW.append("\tExterior Wall,           !- Construction Name\n");
        FW.append("\tliving_unit1,            !- Zone Name\n");
        FW.append("\tOutdoors,                !- Outside Boundary Condition\n");
        FW.append("\t,                        !- Outside Boundary Condition Object\n");
        FW.append("\tSunExposed,              !- Sun Exposure\n");
        FW.append("\tWindExposed,             !- Wind Exposure\n");
        FW.append("\t,                     !- View Factor to Ground\n");
        FW.append("\t4,                       !- Number of Vertices\n");
        FW.append("\t0,                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 3 X-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 3 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+",        !- Vertex 3 Z-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t"+houseHeight+";        !- Vertex 4 Z-coordinate {m}\n\n");

        //Writing Floor to IDF
        FW.append("BuildingSurface:Detailed,\n");
        FW.append("\tFloor_unit1,             !- Name\n");
        FW.append("\tFloor,                   !- Surface Type\n");
        FW.append("\tInterior Floor,          !- Construction Name\n");
        FW.append("\tliving_unit1,            !- Zone Name\n");
        FW.append("\tGroundSlabPreprocessorAverage,  !- Outside Boundary Condition\n");
        FW.append("\tsurfPropOthSdCoefSlabAverage,  !- Outside Boundary Condition Object\n");
        FW.append("\tNoSun,                   !- Sun Exposure\n");
        FW.append("\tNoWind,                  !- Wind Exposure\n");
        FW.append("\t0.0,                     !- View Factor to Ground\n");
        FW.append("\t4,                       !- Number of Vertices\n");
        FW.append("\t0,                       !- Vertex 1 X-coordinate {m}\n");
        FW.append("\t0,                       !- Vertex 1 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 1 Z-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 2 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",                       !- Vertex 2 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 2 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",        !- Vertex 3 X-coordinate {m}\n");
        FW.append("\t"+Ymax+",        !- Vertex 3 Y-coordinate {m}\n");
        FW.append("\t.001,        !- Vertex 3 Z-coordinate {m}\n");
        FW.append("\t"+Xmax+",                       !- Vertex 4 X-coordinate {m}\n");
        FW.append("\t0,        !- Vertex 4 Y-coordinate {m}\n");
        FW.append("\t.001;        !- Vertex 4 Z-coordinate {m}\n\n");
        
	}

	private void writeWindows(int[] selectedExpressions) throws IOException {
		//assumes "windows" are 1 m2. And all windows are evenly distributed around walls
		
		//Retrieving and calculating variables
		double totalWindowArea = sqftOptions[selectedExpressions[4]]*windowPerSqftOptions[selectedExpressions[1]];
		double windowDim1 = Math.sqrt(totalWindowArea/4); //X dimension
        double windowDim2 = Math.sqrt(totalWindowArea/4); //Z dimension
        
        //Checking that the windows are not larger than the walls
        if(windowDim1 >= Xmax){
            System.out.println("WINDOW X DIMENSION LARGER THAN WALL LENGTH. ");
            System.out.println("Attempting resize so that window is max length while still fitting on the wall");
            windowDim1 = Xmax - minimumDistanceFromWindowToWallEdge;
            windowDim2 = totalWindowArea/4/windowDim1;
            if(windowDim2 >= houseHeight){
                System.out.println("WINDOW CANNOT BE RESIZED TO CREATE DESIRED TOTAL AREA");
                System.out.println("Maximum window size being assigned");
                windowDim1 = Xmax - minimumDistanceFromWindowToWallEdge;
                windowDim2 = houseHeight - minimumDistanceFromWindowToWallEdge;
            }else{
                System.out.println("RESIZE SUCCESSFUL");
            }
        }else if(windowDim2 >= houseHeight){
            System.out.println("WINDOW Z DIMENSION LARGER THAN WALL HEIGHT.");
            System.out.println("Attempting resize so that the window is max height while still fitting on the wall");
            windowDim2 = houseHeight-minimumDistanceFromWindowToWallEdge;
            windowDim1 = totalWindowArea/4/windowDim2;
            if(windowDim1 >= Xmax){
                System.out.println("WINDOW CANNOT BE RESIZED TO CREATE DESIRED TOTAL AREA");
                System.out.println("Maximum window size being assigned");
                windowDim1 = Xmax - minimumDistanceFromWindowToWallEdge;
                windowDim2 = houseHeight - minimumDistanceFromWindowToWallEdge;
            }else{
                System.out.println("RESIZE SUCCESSFUL");
            }
        }
        
        //Writing windows the the IDF
        FW.append("Window,\n");
        FW.append("\tWindow_ldf_1.unit1,      !- Name\n");
        FW.append("\tExterior Window,         !- Construction Name\n");
        FW.append("\tWall_ldf_1.unit1,        !- Building Surface Name\n");
        FW.append("\t,                        !- Frame and Divider Name\n");
        FW.append("\t1,                       !- Multiplier\n");
        FW.append("\t"+(.5*(Xmax-windowDim1))+",                       !- Starting X Coordinate {m}\n");
        FW.append("\t"+(.5*(houseHeight-windowDim2))+",       !- Starting Z Coordinate {m}\n");
        FW.append("\t"+windowDim1+",        !- Length {m}\n");
        FW.append("\t"+windowDim2+";        !- Height {m}\n\n");

        FW.append("Window,\n");
        FW.append("\tWindow_ldb_1.unit1,      !- Name\n");
        FW.append("\tExterior Window,         !- Construction Name\n");
        FW.append("\tWall_ldb_1.unit1,        !- Building Surface Name\n");
        FW.append("\t,                        !- Frame and Divider Name\n");
        FW.append("\t1,                       !- Multiplier\n");
        FW.append("\t"+(.5*(Xmax-windowDim1))+",                       !- Starting X Coordinate {m}\n");
        FW.append("\t"+(.5*(houseHeight-windowDim2))+",       !- Starting Z Coordinate {m}\n");
        FW.append("\t"+windowDim1+",        !- Length {m}\n");
        FW.append("\t"+windowDim2+";        !- Height {m}\n\n");

        FW.append("Window,\n");
        FW.append("\tWindow_sdr_1.unit1,      !- Name\n");
        FW.append("\tExterior Window,         !- Construction Name\n");
        FW.append("\tWall_sdr_1.unit1,        !- Building Surface Name\n");
        FW.append("\t,                        !- Frame and Divider Name\n");
        FW.append("\t1,                       !- Multiplier\n");
        FW.append("\t"+(.5*(Xmax-windowDim1))+",                       !- Starting X Coordinate {m}\n");
        FW.append("\t"+(.5*(houseHeight-windowDim2))+",       !- Starting Z Coordinate {m}\n");
        FW.append("\t"+windowDim1+",        !- Length {m}\n");
        FW.append("\t"+windowDim2+";        !- Height {m}\n\n");

        FW.append("Window,\n");
        FW.append("\tWindow_sdl_1.unit1,      !- Name\n");
        FW.append("\tExterior Window,         !- Construction Name\n");
        FW.append("\tWall_sdl_1.unit1,        !- Building Surface Name\n");
        FW.append("\t,                        !- Frame and Divider Name\n");
        FW.append("\t1,                       !- Multiplier\n");
        FW.append("\t"+(.5*(Xmax-windowDim1))+",                       !- Starting X Coordinate {m}\n");
        FW.append("\t"+(.5*(houseHeight-windowDim2))+",       !- Starting Z Coordinate {m}\n");
        FW.append("\t"+windowDim1+",        !- Length {m}\n");
        FW.append("\t"+windowDim2+";        !- Height {m}\n\n");
	}

	private void writeDraftiness(int[]selectedExpressions) throws IOException {
		
		//Retrieving Variable
		double draftLevel = draftOptions[selectedExpressions[3]];
		
		//Writing Draft Characteristics to IDF
		FW.append("ZoneInfiltration:DesignFlowRate,\n");
        FW.append("\tliving_unit1_infiltration,  !- Name\n");
        FW.append("\tliving_unit1,            !- Zone or ZoneList Name\n");
        FW.append("\talwaysOn,                !- Schedule Name\n");
        FW.append("\tAirChanges/Hour,         !- Design Flow Rate Calculation Method\n");
        FW.append("\t,                        !- Design Flow Rate {m3/s}\n");
        FW.append("\t,                        !- Flow per Zone Floor Area {m3/s-m2}\n");
        FW.append("\t,                        !- Flow per Exterior Surface Area {m3/s-m2}\n");
        FW.append("\t"+draftLevel+",                     !- Air Changes per Hour {1/hr}\n");
        FW.append("\t,                        !- Constant Term Coefficient\n");
        FW.append("\t,                        !- Temperature Term Coefficient\n");
        FW.append("\t,                        !- Velocity Term Coefficient\n");
        FW.append("\t;                        !- Velocity Squared Term Coefficient\n\n");

        FW.append("ZoneInfiltration:DesignFlowRate,\n");
        FW.append("\tattic_infiltration,      !- Name\n");
        FW.append("\tattic_unit1,             !- Zone or ZoneList Name\n");
        FW.append("\talwaysOn,                !- Schedule Name\n");
        FW.append("\tAirChanges/Hour,         !- Design Flow Rate Calculation Method\n");
        FW.append("\t,                        !- Design Flow Rate {m3/s}\n");
        FW.append("\t,                        !- Flow per Zone Floor Area {m3/s-m2}\n");
        FW.append("\t,                        !- Flow per Exterior Surface Area {m3/s-m2}\n");
        FW.append("\t"+draftLevel+",                     !- Air Changes per Hour {1/hr}\n");
        FW.append("\t,                        !- Constant Term Coefficient\n");
        FW.append("\t,                        !- Temperature Term Coefficient\n");
        FW.append("\t,                        !- Velocity Term Coefficient\n");
        FW.append("\t;                        !- Velocity Squared Term Coefficient\n\n");

		//Writing Draft Schedule (Always on)
        FW.append("Schedule:Constant,\n");
        FW.append("\talwaysOn,                !- Name\n");
        FW.append("\tOn/Off,                  !- Schedule Type Limits Name\n");
        FW.append("\t1;                       !- Hourly Value\n\n");
	}

	private void writeInsulation(int[]selectedExpressions, int climateZoneNumValue) throws IOException {
		//Retrieving and Calculating Variables
		double actualAtticInsul = recommendedAtticInsulOptions[climateZoneNumValue]*percentOfRecOptions[selectedExpressions[2]];
		double actualFloorInsul = recommendedFloorInsulOptions[climateZoneNumValue]*percentOfRecOptions[selectedExpressions[2]];
		double actualWallInsul = recommendedWallInsulOptions[climateZoneNumValue]*percentOfRecOptions[selectedExpressions[2]];
		
		//Writing to File
		if(actualWallInsul>0 && actualFloorInsul>0 && actualAtticInsul>0){
            //Wall Insulation
            FW.append("Material,\n");
            FW.append("\tBatt_R"+actualWallInsul+",                !- Name\n");
            FW.append("\tMediumRough,             !- Roughness\n");
            FW.append("\t"+(.001336845*actualWallInsul)+",    !- Thickness {m}\n");
            FW.append("\t3.47522010738099E-03,    !- Conductivity {W/m-K}\n");
            FW.append("\t9.61107175253399,        !- Density {kg/m3}\n");
            FW.append("\t836.800006332062,        !- Specific Heat {J/kg-K}\n");
            FW.append("\t0.9,                     !- Thermal Absorptance\n");
            FW.append("\t0.7,                     !- Solar Absorptance\n");
            FW.append("\t0.7;                     !- Visible Absorptance\n\n");
            //Floor Insulation
            FW.append("Material,\n");
            FW.append("\tBatt_R"+actualFloorInsul+",                !- Name\n");
            FW.append("\tMediumRough,             !- Roughness\n");
            FW.append("\t"+(.001336845*actualFloorInsul)+",    !- Thickness {m}\n");
            FW.append("\t3.47522010738099E-03,    !- Conductivity {W/m-K}\n");
            FW.append("\t9.61107175253399,        !- Density {kg/m3}\n");
            FW.append("\t836.800006332062,        !- Specific Heat {J/kg-K}\n");
            FW.append("\t0.9,                     !- Thermal Absorptance\n");
            FW.append("\t0.7,                     !- Solar Absorptance\n");
            FW.append("\t0.7;                     !- Visible Absorptance\n\n");
            //Attic Insulation
            FW.append("Material,\n");
            FW.append("\tBlown_R"+actualAtticInsul+",               !- Name\n");
            FW.append("\tMediumRough,             !- Roughness\n");
            FW.append("\t"+(.0070866*actualFloorInsul)+",    !- Thickness {m}\n");
            FW.append("\t0.04119,                 !- Conductivity {W/m-K}\n");
            FW.append("\t9.61107175253399,        !- Density {kg/m3}\n");
            FW.append("\t836.800006332062;        !- Specific Heat {J/kg-K}\n\n");
        }
        
        //Applying Wall Insulation
        FW.append("Construction,\n");
        FW.append("\tExterior Wall,           !- Name\n");
        FW.append("\tsyn_stucco,              !- Outside Layer\n");
        FW.append("\tsheathing_consol_layer,  !- Layer 2\n");
        FW.append("\tOSB_7/16in,              !- Layer 3\n");
        if(actualWallInsul>0){
            FW.append("\tBatt_R"+actualWallInsul+",                !- Layer 4\n");
        }
        FW.append("\twall_consol_layer,       !- Layer 5\n");
        FW.append("\tDrywall_1/2in;           !- Layer 6\n\n");

        //Applying Attic Insulation
        FW.append("Construction,\n");
        FW.append("\tInterior Ceiling,        !- Name\n");
        if(actualAtticInsul>0){
            FW.append("\tBlown_R"+actualAtticInsul+",       !- Outside Layer\n");
        }
        FW.append("\tceil_consol_layer,       !- Layer 2\n");
        FW.append("\tDrywall_1/2in;           !- Layer 3\n\n");

        //Applying Floor Insulation
        FW.append("Construction,\n");
        FW.append("\tInterior Floor,          !- Name\n");
        FW.append("\tPlywood_3/4in,           !- Outside Layer\n");
        if(actualFloorInsul>0){
            FW.append("\tBatt_R"+actualFloorInsul+",       !- Layer 2\n");
        }
        FW.append("\tCarpet_n_pad;            !- Layer 3\n\n");
	}

	private void writeThermostatBaseline(int[] selectedExpressions) throws IOException {
		//This method only sets up if the thermostat operates for heating and cooling
		//It doesn't add set points
		
		FW.append("ThermostatSetpoint:DualSetpoint,\n");
        FW.append("\tthermostat_living Dual SP Control,  !- Name\n");
        
        if(selectedExpressions[5] == 0){ //if heat is not used, then always set to off. Otherwise, add place for set point schedule
            FW.append("\talwaysOffHeatingSetpoint,             !- Heating Setpoint Temperature Schedule Name\n");
        }else{
            FW.append("\theating_sch,             !- Heating Setpoint Temperature Schedule Name\n");
        }

        if(selectedExpressions[8] == 0){//if cooling is not used, then always set to off. Otherwise, add place for set point schedule
            FW.append("\talwaysOffCoolingSetpoint;             !- Cooling Setpoint Temperature Schedule Name\n\n");
        }else{
            FW.append("\tcooling_sch;             !- Cooling Setpoint Temperature Schedule Name\n\n");
        }

        if(selectedExpressions[5] == 0){ //if heating is not used, set heating set point unrealistically low
            FW.append("Schedule:Compact,\n");
            FW.append("\talwaysOffHeatingSetpoint,             !- Name\n");
            FW.append("\tTemperature,             !- Schedule Type Limits Name\n");
            FW.append("\tThrough: 12/31,          !- Field 1\n");
            FW.append("\tFor: AllDays,            !- Field 2\n");
            FW.append("\tUntil: 24:00,            !- Field 3\n");
            FW.append("\t-60;                   !- Field 4\n");
        }
        if(selectedExpressions[8] == 0){ //if cooling is not used, set cooling set point unrealistically high
            FW.append("Schedule:Compact,\n");
            FW.append("\talwaysOffCoolingSetpoint,             !- Name\n");
            FW.append("\tTemperature,             !- Schedule Type Limits Name\n");
            FW.append("\tThrough: 12/31,          !- Field 1\n");
            FW.append("\tFor: AllDays,            !- Field 2\n");
            FW.append("\tUntil: 24:00,            !- Field 3\n");
            FW.append("\t200;                   !- Field 4\n");
        }
        //if set point is not set here, it will be set in writeCoolSetpoint or writeHeatSetpoint 
    }
	
	private void writeTimeStep(int timeStep) throws IOException {
		FW.append("Timestep,\n");
        FW.append("\t"+timeStep+";                       !- Number of Timesteps per Hour\n\n");
	}
    
	private void getWaterHeaterCharacteristics(int[] selectedExpressions) {
		
		//Get water heater fuel
		fuelH2O = waterHeaterFuelOptions[selectedExpressions[15]];
		
		//Get water heater tank volume
		switch(selectedExpressions[13]){
	        case 0:
	            isTankless = false;
	            cycleType = "Cycle";
	            tankVolume = 0.113562;
	            break;
	        case 1:
	            isTankless = false;
	            cycleType = "Cycle";
	            tankVolume = 0.151416;
	            break;
	        case 2:
	            isTankless = false;
	            cycleType = "Cycle";
	            tankVolume = 0.189271;
	            break;
	        case 3: 
	            isTankless = true;
	            cycleType = "Modulate";
	            tankVolume = 0.00378541;
	            break;
		}
		
		//Get water heater ES status
		switch(selectedExpressions[16]) {
			case 0: isESQual = false;break;
			case 1: isESQual = true;break;
		}
		
		//Get water heater efficiency
		if(isTankless == false){
            if(fuelH2O == "Electricity"){
                if(isESQual == true){
                    switch(selectedExpressions[14]){
                        case 0: efficiency = .945;break;
                        case 1: efficiency = .938;break;
                        case 2: efficiency = .931;break;
                        case 3: efficiency = .923;break;
                        case 4: efficiency = .916;break;
                        case 5: efficiency = .909;break;
                    }
                }else{
                    switch(selectedExpressions[14]){
                        case 0: efficiency = .915;break;
                        case 1: efficiency = .908;break;
                        case 2: efficiency = .901;break;
                        case 3: efficiency = .894;break;
                        case 4: efficiency = .887;break;
                        case 5: efficiency = .880;break;
                    }
                }
            }else if(fuelH2O == "NaturalGas"){
                if(isESQual == true){
                    switch(selectedExpressions[14]){
                        case 0: efficiency = .685;break;
                        case 1: efficiency = .673;break;
                        case 2: efficiency = .662;break;
                        case 3: efficiency = .650;break;
                        case 4: efficiency = .639;break;
                        case 5: efficiency = .627;break;
                    }
                }else{
                    switch(selectedExpressions[14]){
                        case 0: efficiency = .59;break;
                        case 1: efficiency = .58;break;
                        case 2: efficiency = .57;break;
                        case 3: efficiency = .56;break;
                        case 4: efficiency = .55;break;
                        case 5: efficiency = .54;break;
                    }
                }
            }
        }else{
            if(fuelH2O == "Electricity"){
                if(isESQual == true){
                    switch(selectedExpressions[14]){
                        case 0: efficiency = .940;break;
                        case 1: efficiency = .934;break;
                        case 2: efficiency = .927;break;
                        case 3: efficiency = .921;break;
                        case 4: efficiency = .915;break;
                        case 5: efficiency = .909;break;
                    }
                }else{
                    switch(selectedExpressions[14]){
                        case 0: efficiency = .91;break;
                        case 1: efficiency = .904;break;
                        case 2: efficiency = .898;break;
                        case 3: efficiency = .892;break;
                        case 4: efficiency = .886;break;
                        case 5: efficiency = .880;break;
                    }
                }
            }else if(fuelH2O == "NaturalGas"){
                if(isESQual == true){
                    switch(selectedExpressions[14]){
                        case 0: efficiency = .837;break;
                        case 1: efficiency = .781;break;
                        case 2: efficiency = .725;break;
                        case 3: efficiency = .669;break;
                        case 4: efficiency = .613;break;
                        case 5: efficiency = .558;break;
                    }
                }else{
                    switch(selectedExpressions[14]){
                        case 0: efficiency = .81;break;
                        case 1: efficiency = .756;break;
                        case 2: efficiency = .702;break;
                        case 3: efficiency = .648;break;
                        case 4: efficiency = .594;break;
                        case 5: efficiency = .54;break;
                    }
                }
            }
        }
		
		//Get number of bedrooms in house for water heater load
        numberOfBedrooms = (int) Math.ceil(bedroomsPerSqftOptions[selectedExpressions[17]]*sqftOptions[selectedExpressions[4]]);
    
        //Get number of bathrooms in house for water heater load
        numberOfBathrooms = (int) Math.ceil(bathroomsPerSqftOptions[selectedExpressions[18]]*sqftOptions[selectedExpressions[4]]);
		
	}

	private void writeWaterHeater(int[] selectedExpressions) throws IOException{
		getWaterHeaterCharacteristics(selectedExpressions);
		
		//Write Characteristics of the Water Heater
		FW.append("WaterHeater:Mixed,\n");
        FW.append("\tWater Heater_unit1,      !- Name\n");
        FW.append("\t"+tankVolume+",             !- Tank Volume {m3}\n");
        FW.append("\tdhw_setpt,               !- Setpoint Temperature Schedule Name\n");
        FW.append("\t2,                       !- Deadband Temperature Difference {deltaC}\n");
        FW.append("\t50,                      !- Maximum Temperature Limit {C}\n");
        FW.append("\t"+cycleType+",                   !- Heater Control Type\n");
        FW.append("\tautosize,                !- Heater Maximum Capacity {W}\n");
        FW.append("\t0,                       !- Heater Minimum Capacity {W}\n");
        FW.append("\t0,                       !- Heater Ignition Minimum Flow Rate {m3/s}\n");
        FW.append("\t,                        !- Heater Ignition Delay {s}\n");
        FW.append("\t"+fuelH2O+",              !- Heater Fuel Type\n");
        FW.append("\t"+efficiency+",                     !- Heater Thermal Efficiency\n");
        FW.append("\t,                        !- Part Load Factor Curve Name\n");
        FW.append("\t,                        !- Off Cycle Parasitic Fuel Consumption Rate {W}\n");
        FW.append("\t,                        !- Off Cycle Parasitic Fuel Type\n");
        FW.append("\t,                        !- Off Cycle Parasitic Heat Fraction to Tank\n");
        FW.append("\t,                        !- On Cycle Parasitic Fuel Consumption Rate {W}\n");
        FW.append("\t,                        !- On Cycle Parasitic Fuel Type\n");
        FW.append("\t,                        !- On Cycle Parasitic Heat Fraction to Tank\n");
        FW.append("\tZone,                    !- Ambient Temperature Indicator\n");
        FW.append("\t,                        !- Ambient Temperature Schedule Name\n");
        FW.append("\tliving_unit1,            !- Ambient Temperature Zone Name\n");
        FW.append("\t,                        !- Ambient Temperature Outdoor Air Node Name\n");
        FW.append("\t6.27714230487778,        !- Off Cycle Loss Coefficient to Ambient Temperature {W/K}\n");
        FW.append("\t1,                       !- Off Cycle Loss Fraction to Zone\n");
        FW.append("\t6.27714230487778,        !- On Cycle Loss Coefficient to Ambient Temperature {W/K}\n");
        FW.append("\t1,                       !- On Cycle Loss Fraction to Zone\n");
        FW.append("\t0,                       !- Peak Use Flow Rate {m3/s}\n");
        FW.append("\t,                        !- Use Flow Rate Fraction Schedule Name\n");
        FW.append("\t,                        !- Cold Water Supply Temperature Schedule Name\n");
        FW.append("\tWater Heater use inlet node_unit1,  !- Use Side Inlet Node Name\n");
        FW.append("\tWater Heater use outlet node_unit1,  !- Use Side Outlet Node Name\n");
        FW.append("\t1,                       !- Use Side Effectiveness\n");
        FW.append("\t,                        !- Source Side Inlet Node Name\n");
        FW.append("\t,                        !- Source Side Outlet Node Name\n");
        FW.append("\t1,                       !- Source Side Effectiveness\n");
        FW.append("\tautosize,                !- Use Side Design Flow Rate {m3/s}\n");
        FW.append("\t0,                       !- Source Side Design Flow Rate {m3/s}\n");
        FW.append("\t1.5;                     !- Indirect Water Heating Recovery Time {hr}\n\n");
        
        //Write the Water Heater Sizing
        FW.append("WaterHeater:Sizing,\n");
        FW.append("\tWater Heater_unit1,      !- WaterHeater Name\n");
        FW.append("\tResidentialHUD-FHAMinimum,  !- Design Mode\n");
        FW.append("\t,                        !- Time Storage Can Meet Peak Draw {hr}\n");
        FW.append("\t,                        !- Time for Tank Recovery {hr}\n");
        FW.append("\t,                        !- Nominal Tank Volume for Autosizing Plant Connections {m3}\n");
        FW.append("\t"+numberOfBedrooms+",                       !- Number of Bedrooms\n\n");
        FW.append("\t"+numberOfBathrooms+";                       !- Number of Bathrooms\n\n");
    
	}

	private void writeNumberOfMembers(int[] selectedExpressions) throws IOException {
		//Retrieving Variable
		int numberOfMembers = selectedExpressions[10];
		
		//Writing number of members to IDF file
		FW.append("People,\n");
        FW.append("\tpeople_unit1,      !- Name\n");
        FW.append("\tliving_unit1,         !- Zone or ZoneList Name\n");
        FW.append("\tOccupancy,        !- Number of People Schedule Name\n");
        FW.append("\tPeople,                        !- Number of People Calculation Method\n");
        FW.append("\t"+numberOfMembers+",                       !- Number of People\n");
        FW.append("\t,                       !- People per Zone Floor Area {person/m2}\n");
        FW.append("\t,       !- Zone Floor Area per Person {m2/person}\n");
        FW.append("\t0,        !- Fraction Radiant\n");
        FW.append("\tautocalculate,        !- Sensible Heat Fraction\n");
        FW.append("\tactivity_sch,        !- Activity Level Schedule Name\n");
        FW.append("\t,        !- Carbon Dioxide Generation Rate {m3/s-W}\n");
        FW.append("\tNo,        !- Enable ASHRAE 55 Comfort Warnings\n");
        FW.append("\tZoneAveraged;        !- Mean Radiant Temperature Calculation Type\n\n");
        
	}
	
	private void writeThermostatSetpoints(int[] selectedExpressions) throws IOException{
		//Converting set points from F to C
		double coolingSetpoint_F = selectedExpressions[11]+50;
		double coolingSetpoint_C = (coolingSetpoint_F-32)*5/9;
		double heatingSetpoint_F = selectedExpressions[12]+50;
		double heatingSetpoint_C = (heatingSetpoint_F-32)*5/9;
		
		//Writing Cooling set point
        FW.append("Schedule:Compact,\n");
        FW.append("\tcooling_sch,      !- Name\n");
        FW.append("\tTemperature,         !- Schedule Type Limits Name\n");
        FW.append("\tThrough: 12/31,          !- Field 1\n");
        FW.append("\tFor: AllDays,            !- Field 2\n");
        FW.append("\tUntil: 24:00,            !- Field 3\n");
        FW.append("\t"+coolingSetpoint_C+";                   !- Field 4\n");
        //Writing Heating set point
        FW.append("Schedule:Compact,\n");
        FW.append("\theating_sch,      !- Name\n");
        FW.append("\tTemperature,         !- Schedule Type Limits Name\n");
        FW.append("\tThrough: 12/31,          !- Field 1\n");
        FW.append("\tFor: AllDays,            !- Field 2\n");
        FW.append("\tUntil: 24:00,            !- Field 3\n");
        FW.append("\t"+heatingSetpoint_C+";                   !- Field 4\n");
	}

	private void writeLighting(int[] selectedExpressions) throws IOException{
		
		//Retrieving and Calculating Variables
		double lights_annual_kWh_estimate = sqftOptions[selectedExpressions[4]]*lightingPerSqftOptions[selectedExpressions[19]];
		double internal_hardwired_setting = .199378*lights_annual_kWh_estimate;  //Wattage
        double internal_plug_setting = .076317*lights_annual_kWh_estimate;  //Wattage
        double external_garage_setting = .026902*lights_annual_kWh_estimate;  //Wattage
        double external_general_setting = .016217*lights_annual_kWh_estimate;  //Wattage
        //conversions from annual kWh to wattage setting for the various end uses is based on the skeleton models
        
        //Writing Internal Hardwired Lighting
        FW.append("Lights,\n");
        FW.append("\tLiving Hardwired Lighting1,  !- Name\n");
        FW.append("\tliving_unit1,            !- Zone or ZoneList Name\n");
        FW.append("\tInteriorLightingHE,      !- Schedule Name\n");
        FW.append("\tLightingLevel,           !- Design Level Calculation Method\n");
        FW.append("\t"+internal_hardwired_setting+",                   !- Lighting Level {W}\n");
        FW.append("\t ,                        !- Watts per Zone Floor Area {W/m2}\n");
        FW.append("\t,                        !- Watts per Person {W/person}\n");
        FW.append("\t0,                       !- Return Air Fraction\n");
        FW.append("\t0.6,                     !- Fraction Radiant\n");
        FW.append("\t0.2,                     !- Fraction Visible\n");
        FW.append("\t0;                       !- Fraction Replaceable\n\n");
        
        //Writing Lighting Plug Loads
        FW.append("Lights,\n");
        FW.append("\tLiving Plug-in Lighting1,!- Name\n");
        FW.append("\tliving_unit1,            !- Zone or ZoneList Name\n");
        FW.append("\tInteriorLightingHE,      !- Schedule Name\n");
        FW.append("\tLightingLevel,           !- Design Level Calculation Method\n");
        FW.append("\t"+internal_plug_setting+",                   !- Lighting Level {W}\n");
        FW.append("\t ,                        !- Watts per Zone Floor Area {W/m2}\n");
        FW.append("\t,                        !- Watts per Person {W/person}\n");
        FW.append("\t0,                       !- Return Air Fraction\n");
        FW.append("\t0.6,                     !- Fraction Radiant\n");
        FW.append("\t0.2,                     !- Fraction Visible\n");
        FW.append("\t0;                       !- Fraction Replaceable\n\n");
        
        //Writing Garage Lighting
        FW.append("Exterior:Lights,\n");
        FW.append("\tGarage-Lights_unit1,     !- Name\n");
        FW.append("\tInteriorLightingHE,      !- Schedule Name\n");
        FW.append("\t"+external_garage_setting+",        !- Design Level {W}\n");
        FW.append("\t,                        !- Control Option\n");
        FW.append("\tGarage-Lights;           !- End-Use Subcategory\n\n");
        
        //Writing General Outdoor Lighting
        FW.append("Exterior:Lights,\n");
        FW.append("\tExterior-Lights_unit1,   !- Name\n");
        FW.append("\tExteriorLighting,        !- Schedule Name\n");
        FW.append("\t"+external_general_setting+",        !- Design Level {W}\n");
        FW.append("\t,                        !- Control Option\n");
        FW.append("\tExterior-Lights;         !- End-Use Subcategory\n\n");
	}

	private void writeMiscLoads(int[] selectedExpressions)throws IOException{
		
		//Retrieving and Calculating Variables
		double misc_annual_kWh_estimate = sqftOptions[selectedExpressions[4]]*miscPerSqftOptions[selectedExpressions[20]];
		double misc_wattage = .1690*misc_annual_kWh_estimate;
		//conversion from annual kWh to wattage setting is based on the skeleton models
		
		//Writing miscellaneous loads to the IDF
		FW.append("ElectricEquipment,\n");
        FW.append("\tIECC_Adj1,               !- Name\n");
        FW.append("\tliving_unit1,            !- Zone or ZoneList Name\n");
        FW.append("\tMiscPlugLoad,            !- Schedule Name\n");
        FW.append("\tEquipmentLevel,          !- Design Level Calculation Method\n");
        FW.append("\t"+misc_wattage+",                  !- Design Level {W}\n");
        FW.append("\t,                        !- Watts per Zone Floor Area {W/m2}\n");
        FW.append("\t,                        !- Watts per Person {W/person}\n");
        FW.append("\t0.0624390461422629,      !- Fraction Latent\n");
        FW.append("\t0.41190936353998,        !- Fraction Radiant\n");
        FW.append("\t0.251045347957769,       !- Fraction Lost\n");
        FW.append("\tIECC_adj;                !- End-Use Subcategory\n\n");
	}
	
	public void close() throws IOException {
		FW.close();
	}

	public void writeFridgeIDF(int numberOfFridges, int[][] selExp, double[][][][][] fridgekWhInformation) throws IOException {
		double powerConsumption = -1;
		double wattageSetting = -1;
		for(int i = 0; i < numberOfFridges; i++) { //Perform loop for each fridge in the house
			//Calculate wattage of fridge based on its characteristics
			powerConsumption = fridgekWhInformation[selExp[i][0]][selExp[i][1]][selExp[i][2]][selExp[i][3]][0];
			wattageSetting = powerConsumption/7.343; //Back calculated from ES skeleton model
			//Writing to IDF
			FW.append("ElectricEquipment,\n");
            FW.append("\trefrigerator"+ (i+1) +",\t!-Name\n");
            FW.append("\tliving_unit1,            !- Zone or ZoneList Name\n");
            FW.append("\tRefrigerator,            !- Schedule Name\n");
            FW.append("\tEquipmentLevel,          !- Design Level Calculation Method\n");
            FW.append("\t"+wattageSetting+",        !- Design Level {W}\n");
            FW.append("\t,                        !- Watts per Zone Floor Area {W/m2}\n");
            FW.append("\t,                        !- Watts per Person {W/person}\n");
            FW.append("\t0,                       !- Fraction Latent\n");
            FW.append("\t1,                       !- Fraction Radiant\n");
            FW.append("\t0,                       !- Fraction Lost\n");
            FW.append("\trefrigerator;            !- End-Use Subcategory\n\n\n");
		}
	}

	public void writeApplianceOffDay(int applianceTimeStep) throws IOException{
		int nValue = 3;
		//Calculating variables
		int numDailyTimeSteps = 24*applianceTimeStep;
        int timeStepLengthMin = 60/applianceTimeStep;
		//Writing
        FW.append("\nSchedule:Day:List,\n");
        FW.append("\talwaysOffDaySch,\t\t!- Name\n");
        FW.append("\tfraction,\t\t!- Schedule Type Limits Name\n");
        FW.append("\tNo,\t\t!- Interpolate to Timestep\n");
        FW.append("\t"+timeStepLengthMin+",\t\t!- Minutes per Item\n");
        FW.append("\t0,\t\t!- Value 1\n");
        for(int i = 1;i<(numDailyTimeSteps-1);i++){
            FW.append("\t0,\t\t!- N" + nValue + "\n");
            nValue++;
        }
        FW.append("\t0;\t\t!- N" + nValue + "\n");
    }

	public void writeApplianceProfileIDF(String name, int fuelType, double wattage) throws IOException {
		String zoneName = "living_unit1";
		
		if(fuelType == 0){FW.append("\nElectricEquipment,\n");}
        else{FW.append("\nGasEquipment,\n");}
		
		FW.append("\t"+name+",\t!-Name\n");
        FW.append("\t"+zoneName+",\t!-Zone or ZoneList Name\n");
        FW.append("\t"+name+"AnnualSch,\t!-Schedule Name\n");
        FW.append("\tEquipmentLevel,\t!-Design Level Calculation\n");
        FW.append("\t"+wattage+",\t!-Design Level {W}\n");
        FW.append("\t,\t!-Watts per Zone Floor Area {W/m2}\n");
        FW.append("\t,\t!-Watts per Person {W/person}\n");
        if(name.contains("DishWasher")){
            FW.append("\t0.15,\t!-Fraction Latent\n");
            FW.append("\t0.6,\t!-Fraction Radiant\n");
            FW.append("\t0.25,\t!-Fraction Lost\n");
            if(fuelType == 1){FW.append("\t0,\t!-Carbon Dioxide Generation Rate {m3/s-W}\n");}
            FW.append("\tDishWasher;\t!-End-Use Category\n");
        }else if(name.contains("ClothesWasher")){
            FW.append("\t0,\t!-Fraction Latent\n");
            FW.append("\t0.8,\t!-Fraction Radiant\n");
            FW.append("\t0.2,\t!-Fraction Lost\n");
            if(fuelType == 1){FW.append("\t0,\t!-Carbon Dioxide Generation Rate {m3/s-W}\n");}
            FW.append("\tClothesWasher;\t!-End-Use Category\n");
        }else if(name.contains("ClothesDryer")){
            FW.append("\t0.05,\t!-Fraction Latent\n");
            FW.append("\t0.15,\t!-Fraction Radiant\n");
            FW.append("\t0.8,\t!-Fraction Lost\n");
            if(fuelType == 1){FW.append("\t0,\t!-Carbon Dioxide Generation Rate {m3/s-W}\n");}
            FW.append("\tClothesDryer;\t!-End-Use Category\n");
        }else if(name.contains("Cooktop")){
            FW.append("\t0.3,\t!-Fraction Latent\n");
            FW.append("\t0.4,\t!-Fraction Radiant\n");
            FW.append("\t0.3,\t!-Fraction Lost\n");
            if(fuelType == 1){FW.append("\t0,\t!-Carbon Dioxide Generation Rate {m3/s-W}\n");}
            FW.append("\tCooking;\t!-End-Use Category\n");
        }else if(name.contains("Oven")){
            FW.append("\t0.3,\t!-Fraction Latent\n");
            FW.append("\t0.4,\t!-Fraction Radiant\n");
            FW.append("\t0.3,\t!-Fraction Lost\n");
            if(fuelType == 1){FW.append("\t0,\t!-Carbon Dioxide Generation Rate {m3/s-W}\n");}
            FW.append("\tCooking;\t!-End-Use Category\n");
        }else{
            FW.append("\t==============ERROR IN ASSIGNING REST OF PROFILE==================\n");
		}
		
	}

	public void writeAnnualApplianceScheduleIDF(String applianceName) throws IOException {
		int week = 0;
        int month = 1;
        int day = 1;

        FW.append("\nSchedule:Year,\n");
        FW.append("\t"+applianceName+"AnnualSch,\t\t!- Name\n");
        FW.append("\tfraction,\t\t!- Schedule Type Limits Name\n");

        while(month<13){
            FW.append("\tWeek"+week+applianceName+"Sch,\t\t!- Schedule:Week Name "+(week+1)+"\n");
            FW.append("\t"+month+",\t\t!- Start Month "+(week+1)+"\n");
            FW.append("\t"+day+",\t\t!- Start Day "+(week+1)+"\n");
            day=day+6;
            if(month == 12 & day == 30){
                day = 31;
                FW.append("\t"+month+",\t\t!- End Month "+(week+1)+"\n");
                FW.append("\t"+day+";\t\t!- End Day "+(week+1)+"\n");
                break;
            }
            if(day > getMonthLength(month)){
                day = day - getMonthLength(month);
                month++;
            }
            FW.append("\t"+month+",\t\t!- End Month "+(week+1)+"\n");
            FW.append("\t"+day+",\t\t!- End Day "+(week+1)+"\n");
            day++;
            week++;
        }
		
	}
}
