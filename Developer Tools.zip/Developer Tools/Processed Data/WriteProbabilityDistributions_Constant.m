clear
clc
%% Writing Probability Distributions for Structure/Constant Loads
numIncomeCategories = 5;
numClimateZones = 11;
contructionfileName = "ProbDistributions_ConstantCharacteristics.csv"; %for output file for non-fridge characteristics
fridgeFileName = "FridgeProbDistrib.csv"; %for output file of fridge characteristics
numberOfConstructionCharacteristics = 21; %for non-fridge characteristics (see rest of file for clarification)
numberOfFridgeCharacteristics = 5; %fridge characteristics

%read in RECS Data
RECS_Data = readmatrix("RECS_2015_Processed.csv");

%% Calculate Prob Distributions
for income = 1:numIncomeCategories
    for climate = 1:numClimateZones
        RECS_Data_Income_Climate = [];
        RECS_Data_Income = [];

        %Select data for this income-climate classification
        n = 1;
        m = 1;
        for i = 1:length(RECS_Data)
            if RECS_Data(i,2) == climate && RECS_Data(i,3) == income
                RECS_Data_Income_Climate(n,:) = RECS_Data(i,:);
                n = n+1;
            end
            if RECS_Data(i,3) == income
                RECS_Data_Income(m,:) = RECS_Data(i,:);
                m = m+1;
            end
        end
        %Checking if there is data for this income climate classification
        if isempty(RECS_Data_Income_Climate)
            continue;
        end
        %=================================================================
        %FORMATTING GUIDE:
        
        %Section Description (for readability)
        %Column number for relevant variables (reference RECS_Data file)

        %Characteristic Description (for readability)
        %Get data from all households pertaining to this characteristic
        %Count number of entries within an acceptable response range
            % For example, you may want to ignore "didn't respond" (aka -2)
        %Set "n" for purposes of the loop *if response types are not
            % continuous and starting from 1*
        %Peform a for loop through the potential reponse types
        %Count the number of households which give this response option
        %Store the percentage of households which give this response option
        %Increase "n" for purposes of the loop *if response types are not
            % continuous and starting from 1*

        %=================================================================
        % Construction Characteristics
        constructionIndices = [4,5,6,7,8,9,10,11,12];

        %1 - Stories
        storiesData = RECS_Data_Income_Climate(:,constructionIndices(1));
        totalEntries = numel(storiesData(storiesData>=0 & storiesData<40));
        n = 1;
        for j = [10,20,31,32]
            numSelect = numel(storiesData(storiesData==j));
            storiesProbDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
        end

        %2 - Windows/Sqft 
        windowsData = RECS_Data_Income_Climate(:,constructionIndices(2));
        totalEntries = numel(windowsData);
        n = 1;
        j_old  = 57.5e-5; %not 57.6 because of rounding error
        for j = [216,374,532,690,848,1010,1164,1322,1480,1638,100000]*1e-5
            numSelect = numel(windowsData(windowsData>j_old & windowsData<=j));
            windowsProbDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
            j_old = j;
        end

        %3 - Insulation 
        insulationData = RECS_Data_Income_Climate(:,constructionIndices(3));
        totalEntries = numel(insulationData(insulationData>0));
        for j = 1:4
            numSelect = numel(insulationData(insulationData==j));
            insulationProbDistrib(j,income,climate) = numSelect/totalEntries;
        end

        %4 - Draft
        draftData = RECS_Data_Income_Climate(:,constructionIndices(4));
        totalEntries = numel(draftData(draftData>0));
        for j = 1:4
            numSelect = numel(draftData(draftData==j));
            draftProbDistrib(j,income,climate) = numSelect/totalEntries;
        end

        %5 - Total Sqft
        sqftData = RECS_Data_Income_Climate(:,constructionIndices(5));
        totalEntries = numel(sqftData(sqftData>0));
        n = 1;
        j_old = 0;
        for j = [1,2,3,4,5,6,7,8,9]*1e3
            numSelect = numel(sqftData(sqftData > j_old & sqftData <= j));
            sqftProbDistrib(n,income,climate) = numSelect/totalEntries;
            j_old = j;
            n = n+1;
        end

        %6 - Heat Used
        heatUsedData = RECS_Data_Income_Climate(:,constructionIndices(6));
        totalEntries = numel(heatUsedData(heatUsedData>=0));
        for j = 0:1
            numSelect = numel(heatUsedData(heatUsedData==j));
            heatUsedDistrib(j+1,income,climate) = numSelect/totalEntries;
        end

        %7 - Heat Equipment
        heatEquipData = RECS_Data_Income_Climate(:,constructionIndices(7));
        totalEntries = numel(heatEquipData(heatEquipData>0 & heatEquipData<21));
        n = 1;
        for j = 2:10
            numSelect = numel(heatEquipData(heatEquipData==j));
            heatEquipDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
        end

        %8 - Heating Fuel
        heatFuelData = RECS_Data_Income_Climate(:,constructionIndices(8));
        totalEntries = numel(heatFuelData(heatFuelData>0 & heatFuelData<21));
        n = 1;
        for j = [1,2,3,5,7]
            numSelect = numel(heatFuelData(heatFuelData==j));
            heatFuelDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
        end

        %9 - Cooling Used
        coolingData = RECS_Data_Income_Climate(:,constructionIndices(9));
        totalEntries = numel(coolingData(coolingData>=0));
        for j = 0:1
            numSelect = numel(coolingData(coolingData==j));
            coolingDistrib(j+1,income,climate) = numSelect/totalEntries;
        end

        %=================================================================
        %Fridge Characteristics
        fridgeIndices = [13,14,15,16,17];

        %1 - EnergyStar
        fridge_ES_Data = RECS_Data_Income(:,fridgeIndices(1));
        totalEntries = numel(fridge_ES_Data(fridge_ES_Data>=0));
        for j = 0:1
            numSelect = numel(fridge_ES_Data(fridge_ES_Data==j));
            fridge_ES_Distrib(j+1,income) = numSelect/totalEntries;
        end

        %2 - Number
        fridge_Num_Data = RECS_Data_Income(:,fridgeIndices(2));
        totalEntries = numel(fridge_Num_Data(fridge_Num_Data>=0));
        for j = 0:7
            numSelect = numel(fridge_Num_Data(fridge_Num_Data==j));
            fridge_Num_Distrib(j+1,income) = numSelect/totalEntries;
        end
        
        %3 - Size
        fridge_Size_Data = RECS_Data_Income(:,fridgeIndices(3));
        totalEntries = numel(fridge_Size_Data(fridge_Size_Data>0));
        for j = 1:5
            numSelect = numel( fridge_Size_Data( fridge_Size_Data==j));
            fridge_Size_Distrib(j,income) = numSelect/totalEntries;
        end

        %4 - Door Arrangement
        fridge_Door_Data = RECS_Data_Income(:,fridgeIndices(4));
        totalEntries = numel(fridge_Door_Data(fridge_Door_Data>0));
        n = 1;
        for j = [1,21,22,23,5]
            numSelect = numel(fridge_Door_Data(fridge_Door_Data==j));
            fridge_Door_Distrib(n,income) = numSelect/totalEntries;
            n = n+1;
        end

        %5 - Age
        fridge_Age_Data = RECS_Data_Income_Climate(:,fridgeIndices(5));
        totalEntries = numel(fridge_Age_Data(fridge_Age_Data>0));
        n = 1;
        for j = [1,2,3,41,42,5]
            numSelect = numel(fridge_Age_Data(fridge_Age_Data==j));
            fridge_Age_Distrib(n,income) = numSelect/totalEntries;
            n = n+1;
        end

        %==================================================================
        %Occupant Behaviors
        occupantIndices = [18,19,20];

        %1 - Number of Members
        numMemData = RECS_Data_Income_Climate(:,occupantIndices(1));
        totalEntries = numel(numMemData(numMemData>0));
        for j = 1:20
            numSelect = numel(numMemData(numMemData==j));
            numMemDistrib(j,income,climate) = numSelect/totalEntries;
        end

        %2 - Heating Setpoint
        heatSetpointData = RECS_Data_Income_Climate(:,occupantIndices(2));
        totalEntries = numel(heatSetpointData(heatSetpointData>=50 & heatSetpointData<=90));
        n = 1;
        for j = 50:90
            numSelect = numel(heatSetpointData(heatSetpointData==j));
            heatSetpointDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
        end

        %3 - Cooling Setpoint
        coolSetpointData = RECS_Data_Income_Climate(:,occupantIndices(3));
        totalEntries = numel(coolSetpointData(coolSetpointData>=50 & coolSetpointData<=90));
        n = 1;
        for j = 50:90
            numSelect = numel(coolSetpointData(coolSetpointData==j));
            coolSetpointDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
        end
        %=================================================================
        %Water Heater 
        waterHeaterIndices = [21,22,23,24,25,26];

        %1 - Size
        WHSizeData = RECS_Data_Income_Climate(:,waterHeaterIndices(1));
        totalEntries = numel(WHSizeData(WHSizeData>0));
        for j = 1:4
            numSelect = numel(WHSizeData(WHSizeData==j));
            WHSizeDistrib(j,income,climate) = numSelect/totalEntries;
        end

        %2 - Age
        WHAgeData = RECS_Data_Income_Climate(:,waterHeaterIndices(2));
        totalEntries = numel(WHAgeData(WHAgeData>0));
        n = 1;
        for j = [1,2,3,41,42,5]
            numSelect = numel(WHAgeData(WHAgeData==j));
           WHAgeDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
        end

        %3 - Fuel 
        WHFuelData = RECS_Data_Income_Climate(:,waterHeaterIndices(3));
        totalEntries = numel(WHFuelData(WHFuelData==1 | WHFuelData==2 | WHFuelData==5));
        n = 1;
        for j = [1,2,5]
           numSelect = numel(WHFuelData(WHFuelData==j));
           if j == 2
               WHFuelDistrib(1,income,climate) =  WHFuelDistrib(1,income,climate)+numSelect/totalEntries;
           else
               WHFuelDistrib(n,income,climate) = numSelect/totalEntries;
               n = n+1;
           end
           
        end

        %4 - Energy Star
        WH_ES_Data = RECS_Data_Income_Climate(:,waterHeaterIndices(4));
        totalEntries = numel(WH_ES_Data(WH_ES_Data>=0));
        for j = 0:1
            numSelect = numel(WH_ES_Data(WH_ES_Data==j));
            WH_ES_Distrib(j+1,income,climate) = numSelect/totalEntries;
        end

        %5 - Bed/Sqft
        bedSqftData = RECS_Data_Income_Climate(:,waterHeaterIndices(5));
        totalEntries = numel(bedSqftData(bedSqftData>0));
        n = 1;
        j_old = 0;
        for j = [30, 60, 90, 120, 150, 180, 210, 240, 270, 300,10000]*1e-5
            numSelect = numel(bedSqftData(bedSqftData > j_old & bedSqftData <= j));
            bedSqftDistrib(n,income,climate) = numSelect/totalEntries;
            j_old = j;
            n = n+1;
        end

        %6 - Bath/Sqft
        bathSqftData = RECS_Data_Income_Climate(:,waterHeaterIndices(6));
        totalEntries = numel(bathSqftData(bathSqftData>0));
        n = 1;
        j_old = 0;
        for j = [24, 48, 72, 96, 120, 144, 168, 192, 216, 240,100000]*1e-5
            numSelect = numel(bathSqftData(bathSqftData > j_old & bathSqftData <= j));
            bathSqftDistrib(n,income,climate) = numSelect/totalEntries;
            j_old = j;
            n = n+1;
        end
     
        %================================================================
        %Lights and Misc
        light_misc_Indices = [27,28];
        %Lights/Sqft
        LightsData = RECS_Data_Income_Climate(:,light_misc_Indices(1));
        totalEntries = numel(LightsData);
        n = 1;
        j_old  = 0;
        for j = [5.63,13.63,21.63,29.63,37.63,45.63,53.63,61.63,69.63,77.63,85.63,10000]*1e-2
            numSelect = numel(LightsData(LightsData>j_old & LightsData<=j));
            LightsProbDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
            j_old = j;
        end

         %Misc/Sqft
        MiscData = RECS_Data_Income_Climate(:,light_misc_Indices(2));
        totalEntries = numel(MiscData);
        n = 1;
        j_old  = 0;
        for j = [6, 15, 24, 33,42, 51, 60, 69, 78, 87, 96, 105, 10000]*1e-2
            numSelect = numel(MiscData(MiscData>j_old & MiscData<=j));
            MiscProbDistrib(n,income,climate) = numSelect/totalEntries;
            n = n+1;
            j_old = j;
        end
    end
end
%% Write to File
%Construction Probability
for dataset = 1:numberOfConstructionCharacteristics
    switch dataset
        case 1
            Data = storiesProbDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: NUM OF STORIES   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=======1 / 2 / 3 / 4+ ==============="],contructionfileName,"WriteMode","append")
        case 2
            Data = windowsProbDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: NUM OF WINDOWS PER SQFT   ###"],contructionfileName,"WriteMode","append")
            writematrix(["======= 57.6-216, 216-374, 374-532,532-690,690-848,848-1010,1010-1164,1164-1322,1322-1480,1480-1638,1638+ (e-5) ==============="],contructionfileName,"WriteMode","append")
        case 3
            Data = insulationProbDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: LEVEL OF INSULATION   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=======WELL / ADEQUATE / POOR / NOT==============="],contructionfileName,"WriteMode","append")
        case 4
            Data = draftProbDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: FREQ OF DRAFT   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=======ALWAYS / MOSTLY / SOMETIMES / NEVER==============="],contructionfileName,"WriteMode","append")
        case 5
            Data = sqftProbDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: TOTAL SQFT   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=======<1 / 1-2 / 2-3 / 3-4 / 4-5 / 5-6 / 6-7 / 7-8 / 8+ (e3)==============="],contructionfileName,"WriteMode","append")
        case 6
            Data = heatUsedDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: HEAT USED   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=======F/T==============="],contructionfileName,"WriteMode","append")
        case 7
            Data = heatEquipDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: TYPE HEAT   ###"],contructionfileName,"WriteMode","append")
            writematrix(["====HOTWATER/CENTRAL/HEATPUMP/INSTALLEDELECTRIC/BUILTIN PIPELESS/BUILTIN BURNING/WOODBURNING/FIREPLACE/PORTABLE ELEC======="],contructionfileName,"WriteMode","append")
        case 8
            Data = heatFuelDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: HEAT FUEL   ###"],contructionfileName,"WriteMode","append")
            writematrix(["======NAT.GAS/PROPANE/OIL/ELEC/WOOD====="],contructionfileName,"WriteMode","append")
        case 9
            Data = coolingDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: COOL USED   ###"],contructionfileName,"WriteMode","append")
            writematrix(["===========F/T========="],contructionfileName,"WriteMode","append")
        case 10
            Data = ones(1,numIncomeCategories,numClimateZones);
            writematrix(["";"###   NEW CHARACTERISTIC: TYPE COOL !not currently implemented   ###"],contructionfileName,"WriteMode","append")
            writematrix(["===========CENTRAL/INDIVIDUAL========="],contructionfileName,"WriteMode","append")
        case 11
            Data = numMemDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: NUM OF MEMBERS   ###"],contructionfileName,"WriteMode","append")
            writematrix(["======= 1 - 20 ==============="],contructionfileName,"WriteMode","append")
        case 12
            Data = coolSetpointDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: COOLING SETPOINT - HOME   ###"],contructionfileName,"WriteMode","append")
            writematrix(["======= 50-90 [F] ==============="],contructionfileName,"WriteMode","append")
        case 13
            Data = heatSetpointDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: HEATING SETPOINT - HOME   ###"],contructionfileName,"WriteMode","append")
            writematrix(["======= 50-90 [F] ==============="],contructionfileName,"WriteMode","append")
        case 14
            Data = WHSizeDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: WATER HEATER SIZE   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=======Small/Medium/Large/Tankless==============="],contructionfileName,"WriteMode","append")
        case 15
            Data =WHAgeDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: WATER HEATER AGE   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=======<2/2-4/5-9/10-14/15-19/20+==============="],contructionfileName,"WriteMode","append")
        case 16
            Data = WHFuelDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: WATER HEATER FUEL   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=======Gas / Electric ==============="],contructionfileName,"WriteMode","append")
        case 17
            Data = WH_ES_Distrib;
            writematrix(["";"###   NEW CHARACTERISTIC: WATER HEATER ENERGY STAR QUALIFIED   ###"],contructionfileName,"WriteMode","append")
            writematrix(["======= F/ T ==============="],contructionfileName,"WriteMode","append")
        case 18
            Data = bedSqftDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: BEDROOMS / SQUARE FOOT   ###"],contructionfileName,"WriteMode","append")
            writematrix(["======= 0-30, 31-60, 61-90, 91-120, 121-150, 151-180, 181-210, 211-240, 241-270, 271-300, 301+ (e-5) ==============="],contructionfileName,"WriteMode","append")
        case 19
            Data = bathSqftDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: BATHROOMS / SQUARE FOOT   ###"],contructionfileName,"WriteMode","append")
            writematrix(["======= 0-24, 25-48, 49-72, 73-96, 97-120, 121-144, 145-168, 169-192, 193-216, 217-240, 241+ (e-5) ==============="],contructionfileName,"WriteMode","append")
        case 20
            Data = LightsProbDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: LIGHTING/SQFT   ###"],contructionfileName,"WriteMode","append")
            writematrix(["=========<5.63,5.63-13.63,13.63-21.63,21.63-29.63,29.63-37.63,37.63-45.63,45.63-53.63,53.63-61.63,61.63-69.63,69.63-77.63,77.63-85.63,>85.63 (e-2)============="],contructionfileName,"WriteMode","append")
        case 21
            Data = MiscProbDistrib;
            writematrix(["";"###   NEW CHARACTERISTIC: MISC/SQFT   ###"],contructionfileName,"WriteMode","append")
            writematrix(["==========<6, 6-15, 15-24, 24-33,33-42, 42-51, 51-60, 60-69, 69-78, 78-87, 87-96, 96-105, 105+ (+.49e-2)============"],contructionfileName,"WriteMode","append")
    end
    for income = 1:numIncomeCategories
        for climate = 1:numClimateZones
            switch climate 
                case 1
                    IECC = "1A-2A";
                case 2
                    IECC = "2B";
                case 3 
                    IECC = "3A";
                case 4 
                    IECC = "3B-4B";
                case 5
                    IECC = "3C";
                case 6
                    IECC = "4A";
                case 7
                    IECC = "4C";
                case 8 
                    IECC = "5A";
                case 9
                    IECC = "5B-5C";
                case 10
                    IECC = "6A-6B";
                case 11
                    IECC = "7A-7B-7AK-8AK";
            end
            IL = income-1;
            writematrix(["IECC: ",IECC,"  INCOME: ", IL],contructionfileName,"WriteMode","append")
            writematrix(transpose(Data(:,income,climate)),contructionfileName,"WriteMode","append")
        end
    end
end
%Fridge Probability
for dataset = 1:numberOfFridgeCharacteristics
    switch dataset
        case 1
            Data = fridge_ES_Distrib;
            writematrix(["";"###   NEW CHARACTERISTIC: ESQUAL   ###"],fridgeFileName,"WriteMode","append")
            writematrix(["======= F/T ==============="],fridgeFileName,"WriteMode","append")
        case 2
            Data = fridge_Door_Distrib;
            writematrix(["";"###   NEW CHARACTERISTIC: DOOR ARRANGE   ###"],fridgeFileName,"WriteMode","append")
            writematrix(["======= ONE / TWO(FREEZENEXT) / TWO(FREEZEABOVE) / TWO(FREEZEBELOW) / THREE+ ==============="],fridgeFileName,"WriteMode","append")
        case 3 
            Data = fridge_Age_Distrib;
            writematrix(["";"###   NEW CHARACTERISTIC: AGE   ###"],fridgeFileName,"WriteMode","append")
            writematrix(["======= <2 / 2-4 / 5-9 / 10-14 / 15-19 / 20+ ==============="],fridgeFileName,"WriteMode","append")
        case 4 
            Data = fridge_Size_Distrib;
            writematrix(["";"###   NEW CHARACTERISTIC: SIZE   ###"],fridgeFileName,"WriteMode","append")
            writematrix(["======= COMPACT / SMALL / MED / LARGE / VERY LARGE ==============="],fridgeFileName,"WriteMode","append")
        case 5
            Data = fridge_Num_Distrib;
            writematrix(["";"###   NEW CHARACTERISTIC: NUMBER   ###"],fridgeFileName,"WriteMode","append")
            writematrix(["======= 0-7 ==============="],fridgeFileName,"WriteMode","append")
    end
    for income  = 1:numIncomeCategories
        IL = income -1;
        writematrix(["INCOME: ", IL],fridgeFileName,"WriteMode","append")
        writematrix(transpose(Data(:,income)),fridgeFileName,"WriteMode","append")
    end
end
disp("DONE")
