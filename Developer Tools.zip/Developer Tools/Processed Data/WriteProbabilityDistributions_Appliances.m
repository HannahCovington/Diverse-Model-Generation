clear
clc
%% Writing Probability Distributions for Appliances
numIncomeCategories = 5; %number of income categories in data set
numTimeStep = 24*4; %total number of time steps in a day
fileName = "ProbDistributions_Appliances.csv"; %output file name
numberOfAppliances = 5;

%read in the RECS data
RECS_Data = readmatrix("RECS_2015_Processed.csv");
%read in ATUS data
ATUS_Data = readmatrix("ATUS2019_ApplianceStart_15min.csv");
%read in other data
Power_Info = readmatrix("WattageInformation.csv");
StartTimes = readmatrix("StartTimes_15min.csv");

%% Constant Properties (RECS Data)

%Separate into respective matrices
%1 = CT, 2 = O, 3 = DW, 4 = CW, 5 = CD
maxRuns = [37,16,13,18,18];
maxNumber = [4,3,1,1,1]; %(CD,CW,DW = binary, CT = max of 4, O = max of 3)
%indices = [33,36,39,42,44];
indices = [29,32,35,38,40];

for i = 1:numIncomeCategories
    RECS_Data_Income = [];
    %get data for this income level
    n = 1;
    for j = 1:size(RECS_Data)
        if(RECS_Data(j,3)==i)
            RECS_Data_Income(n,:) = RECS_Data(j,:);
            n = n+1;
        end
    end
    
    for appl = 1:numberOfAppliances
        %Presence 
        appliancePresenceData = RECS_Data_Income(:,indices(appl));
        totalEntries = numel(appliancePresenceData(appliancePresenceData>=0));
        for j = 0:maxNumber(appl)
            numSelect = numel(appliancePresenceData(appliancePresenceData==j));
            appliancePresenceDistrib(j+1,i,appl) = numSelect/totalEntries;
        end

        %Number of Runs
        applianceRunData = RECS_Data_Income(:,indices(appl)+1);
        totalEntries = numel(applianceRunData(applianceRunData>=0 & applianceRunData<=maxRuns(appl)));
        for j = 0:maxRuns(appl)
            numSelect = numel(applianceRunData(applianceRunData==j));
            applianceRunDistrib(j+1,i,appl) = numSelect/totalEntries;
        end
    end

    for appl = [1,2,5]
        %Fuel Type
        applianceFuelData = RECS_Data_Income(:,indices(appl)+2);
        totalEntries = numel(applianceFuelData(applianceFuelData>=0 & applianceFuelData<21));
        n = 1;
        for j = [1,2,5]
            numSelect = numel(applianceFuelData(applianceFuelData==j));
            applianceFuelDistrib(n,i,appl) = numSelect/totalEntries;
            n = n+1;
        end
    end

    %Dishwasher Duration
    dishwasherDurationData = RECS_Data_Income(:,indices(3)+2);
    totalEntries = numel(dishwasherDurationData(dishwasherDurationData>0));
    for j = 1:5
        numSelect = numel(dishwasherDurationData(dishwasherDurationData==j));
        dishwasherDurationDistrib(j,i) = numSelect/totalEntries;
    end
    DW_Dur(1,i) = sum(dishwasherDurationDistrib(1,i)); %Normal
    DW_Dur(2,i) = sum(dishwasherDurationDistrib(4:5,i)); %Light
    DW_Dur(3,i) = sum(dishwasherDurationDistrib(2:3,i)); %Heavy

    
    %EnergyStar Classifications
    n = 1;
    for EnergyStarindices = [44,43,45] %dw,cw,cd
        energyStarData = RECS_Data_Income(:,EnergyStarindices);
        totalEntries = numel(energyStarData(energyStarData>=0));
        numSelect = numel(energyStarData(energyStarData==1));
        EnergyStar_Prob(n,i) = numSelect/totalEntries;
        n = n+1;
    end
    EnergyStar_Prob(4:5,:) = 0;

end

CD_P_prsc = appliancePresenceDistrib(1:maxNumber(5)+1,:,5);
CD_U_prsc = applianceRunDistrib(1:maxRuns(5)+1,:,5);
CD_F_prsc(1,:) = sum(applianceFuelDistrib(1:2,:,5));
CD_F_prsc(2,:) = applianceFuelDistrib(3,:,5);

CW_P_prsc = appliancePresenceDistrib(1:maxNumber(4)+1,:,4);
CW_U_prsc = applianceRunDistrib(1:maxRuns(4)+1,:,4);

CT_N_prsc = appliancePresenceDistrib(1:maxNumber(1)+1,:,1);
CT_U_prsc = applianceRunDistrib(1:maxRuns(1)+1,:,1);
CT_F_prsc(1,:) = sum(applianceFuelDistrib(1:2,:,1));
CT_F_prsc(2,:) = applianceFuelDistrib(3,:,1);

DW_P_prsc = appliancePresenceDistrib(1:maxNumber(3)+1,:,3);
DW_U_prsc = applianceRunDistrib(1:maxRuns(3)+1,:,3);

O_N_prsc = appliancePresenceDistrib(1:maxNumber(2)+1,:,2);
O_U_prsc = applianceRunDistrib(1:maxRuns(2)+1,:,2);
O_F_prsc(1,:) = sum(applianceFuelDistrib(1:2,:,2));
O_F_prsc(2,:) = applianceFuelDistrib(3,:,2);

%% Time-Specific Properties (ATUS)
numOfActivities = 3;
activityList = [20102,20201,20203]; %20102 = Laundry, 20201 = Food Prep (aka Cooking), 20203 = Kitchen cleanup (aka Dishwasher)
%create matrices
Day_of_Week = [7,numIncomeCategories,numOfActivities];
Day_of_Week_Totals = [7,numIncomeCategories]; 
Week_Day_Time = [numTimeStep,numIncomeCategories,numOfActivities];
Week_End_Day_Time = [numTimeStep,numIncomeCategories,numOfActivities];

%sort data
activityIndex = 0;
for activity = activityList
    activityIndex = activityIndex + 1;
    for income = 1:numIncomeCategories 
        %Day of Week
        for day = 1:7
            count = 0;
            totalHouses = [];
            totalCount = 1;
            for i = 1:size(ATUS_Data,1)
                %total houses surveyed in this income level and day
                if(ATUS_Data(i,2) == income && ATUS_Data(i,5) == day)
                    totalHouses(totalCount) = ATUS_Data(i,1);
                    totalCount = totalCount+1;
                end
                %houses that ran appliance in income level and day
                if(ATUS_Data(i,3) == activity && ATUS_Data(i,2) == income && ATUS_Data(i,5) == day) 
                    count = count+1;
                end
            end
            Day_of_Week(day,income,activityIndex) = count;
            Day_of_Week_Totals(day,income) = length(unique(totalHouses));
        end
        %Week Day (Day Type = 1)
        timeIndex = 0;
        for startTime = StartTimes
            count = 0;
            timeIndex = timeIndex + 1;
            for i = 1:size(ATUS_Data,1)
                if(ATUS_Data(i,3)==activity && ATUS_Data(i,2)==income && ATUS_Data(i,6) == 1 && ATUS_Data(i,7) == startTime)
                    count = count+1;
                end
            end
            Week_Day_Time(timeIndex,income,activityIndex) = count;
        end
        %Week End Day (Day Type = 2)
        timeIndex = 0;
        for startTime = StartTimes
            timeIndex = timeIndex + 1;
            count = 0;
            for i = 1:size(ATUS_Data,1)
                if(ATUS_Data(i,3)==activity && ATUS_Data(i,2)==income && ATUS_Data(i,6) == 2 && ATUS_Data(i,7) == startTime)
                    count = count + 1;
                end
            end
            Week_End_Day_Time(timeIndex,income,activityIndex) = count;
        end
    end
end

%Process ATUS

%Day of Week Data
%divide each entry by total surveyed households for that category (eg.account for more interviewees on Sunday)
Day_of_Week_Processed = [7,numIncomeCategories,numOfActivities];
for activity = 1:numOfActivities
    for income = 1:numIncomeCategories
        for day = 1:7
            Day_of_Week_Processed(day,income,activity) = Day_of_Week(day,income,activity)/Day_of_Week_Totals(day,income);
        end
    end
end
%sum each column and divide by total to make probabilites sum up to 1
Day_of_Week_Probs = [7,numIncomeCategories,numOfActivities];
for activity = 1:numOfActivities
    for income = 1:numIncomeCategories
        for day = 1:7
            Day_of_Week_Probs(day,income,activity) = Day_of_Week_Processed(day,income,activity)/sum(Day_of_Week_Processed(:,income,activity),1);
        end
    end
end

%Time of Day Data
Week_Day_Time_Probs = [numTimeStep,numIncomeCategories,numOfActivities];
Week_End_Day_Time_Probs = [numTimeStep,numIncomeCategories,numOfActivities];
for activity = 1:numOfActivities
    for income = 1:numIncomeCategories
        for timeSlot = 1:numTimeStep
            Week_Day_Time_Probs(timeSlot,income,activity) = Week_Day_Time(timeSlot,income,activity)/sum(Week_Day_Time(:,income,activity),1);
            Week_End_Day_Time_Probs(timeSlot,income,activity) = Week_End_Day_Time(timeSlot,income,activity)/sum(Week_End_Day_Time(:,income,activity),1);
        end
    end
end

%WRITING OUTPUT============================================================
for income = 1:numIncomeCategories
    writematrix("###Income:,"+(income-1)+", ###",fileName,"WriteMode","append")
    for appl = 1:numberOfAppliances
        switch(appl)
            case 1
                writematrix("=== DishWasher ===",fileName,"WriteMode","append");
            case 2
                writematrix("=== ClothesWasher ===",fileName,"WriteMode","append");
            case 3
                writematrix("=== ClothesDryer ===",fileName,"WriteMode","append");
            case 4
                writematrix("=== Cooktop ===",fileName,"WriteMode","append");
            case 5
                writematrix("=== Oven ===",fileName,"WriteMode","append");
        end
        writematrix("*DURATION CLASSFICATION (1 = constant value, - = meal times, 0.00 = probability for cycle)",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix(transpose(DW_Dur(:,income)),fileName,"WriteMode","append");
            case 2
                writematrix(1,fileName,"WriteMode","append");
            case 3
                writematrix(1,fileName,"WriteMode","append");
            case 4
                writematrix([-1,-2,-3],fileName,"WriteMode","append");
            case 5
                writematrix([-1,-2,-3],fileName,"WriteMode","append");
        end
        writematrix("*DURATION (IN NUMBER OF TIME STEPS)",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix([6,6,8],fileName,"WriteMode","append");
            case 2
                writematrix(4,fileName,"WriteMode","append");
            case 3
                writematrix(4,fileName,"WriteMode","append");
            case 4
                writematrix([1,1,2],fileName,"WriteMode","append");
            case 5
                writematrix([1,1,3],fileName,"WriteMode","append");
        end
        writematrix("*PRESENCE INFORMATION (If one #, likelihood of NOT being present)",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix([DW_P_prsc(income),1-DW_P_prsc(income)],fileName,"WriteMode","append");
            case 2
                writematrix([CW_P_prsc(income),1-CW_P_prsc(income)],fileName,"WriteMode","append");
            case 3
                writematrix([CD_P_prsc(income),1-CD_P_prsc(income)],fileName,"WriteMode","append");
            case 4
                writematrix(transpose(CT_N_prsc(:,income)),fileName,"WriteMode","append");
            case 5
                writematrix(transpose(O_N_prsc(:,income)),fileName,"WriteMode","append");
        end
        writematrix("*NUMBER OF RUNS PER WEEK OPTIONS",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix(0:(height(DW_U_prsc)-1),fileName,"WriteMode","append");
            case 2
                writematrix(0:(height(CW_U_prsc)-1),fileName,"WriteMode","append");
            case 3
                writematrix(0:(height(CD_U_prsc)-1),fileName,"WriteMode","append");
            case 4
                writematrix(0:(height(CT_U_prsc)-1),fileName,"WriteMode","append");
            case 5
                writematrix(0:(height(O_U_prsc)-1),fileName,"WriteMode","append");
        end
        writematrix("*NUMBER OF RUNS PER WEEK PROBABILITIES",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix(transpose(DW_U_prsc(:,income)),fileName,"WriteMode","append");
            case 2
                writematrix(transpose(CW_U_prsc(:,income)),fileName,"WriteMode","append");
            case 3
                writematrix(transpose(CD_U_prsc(:,income)),fileName,"WriteMode","append");
            case 4
                writematrix(transpose(CT_U_prsc(:,income)),fileName,"WriteMode","append");
            case 5
                writematrix(transpose(O_U_prsc(:,income)),fileName,"WriteMode","append");
        end
        writematrix("*DAY OF WEEK PROBABILITY DISTRIBUTION",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix(transpose(Day_of_Week_Probs(:,income,3)),fileName,"WriteMode","append");
            case 2
                writematrix(transpose(Day_of_Week_Probs(:,income,1)),fileName,"WriteMode","append");
            case 3
                writematrix(transpose(Day_of_Week_Probs(:,income,1)),fileName,"WriteMode","append");
            case 4
                writematrix(transpose(Day_of_Week_Probs(:,income,2)),fileName,"WriteMode","append");
            case 5
                writematrix(transpose(Day_of_Week_Probs(:,income,3)),fileName,"WriteMode","append");
        end
        writematrix("*WEEK DAY TIME PROBABILITY DISTRIBUTION",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix(transpose(Week_Day_Time_Probs(:,income,3)),fileName,"WriteMode","append");
            case 2
                writematrix(transpose(Week_Day_Time_Probs(:,income,1)),fileName,"WriteMode","append");
            case 3
                writematrix(transpose(Week_Day_Time_Probs(:,income,1)),fileName,"WriteMode","append");
            case 4
                writematrix(transpose(Week_Day_Time_Probs(:,income,2)),fileName,"WriteMode","append");
            case 5
                writematrix(transpose(Week_Day_Time_Probs(:,income,3)),fileName,"WriteMode","append");
        end
        writematrix("*WEEK END DAY TIME PROBABILITY DISTRIBUTION",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix(transpose(Week_End_Day_Time_Probs(:,income,3)),fileName,"WriteMode","append");
            case 2
                writematrix(transpose(Week_End_Day_Time_Probs(:,income,1)),fileName,"WriteMode","append");
            case 3
                writematrix(transpose(Week_End_Day_Time_Probs(:,income,1)),fileName,"WriteMode","append");
            case 4
                writematrix(transpose(Week_End_Day_Time_Probs(:,income,2)),fileName,"WriteMode","append");
            case 5
                writematrix(transpose(Week_End_Day_Time_Probs(:,income,3)),fileName,"WriteMode","append");
        end
        writematrix("*ENERGY STAR PROBABILITY (F/T)",fileName,"WriteMode","append");
        writematrix([1-EnergyStar_Prob(appl,income),EnergyStar_Prob(appl,income)],fileName,"WriteMode","append");
        writematrix("*FUEL TYPE PROBABILITY (Electricity/Gas)",fileName,"WriteMode","append");
        switch(appl)
            case 1
                writematrix([1,0],fileName,"WriteMode","append");
            case 2
                writematrix([1,0],fileName,"WriteMode","append");
            case 3
                writematrix([CD_F_prsc(2,income),CD_F_prsc(1,income)],fileName,"WriteMode","append");
            case 4
                writematrix([CT_F_prsc(2,income),CT_F_prsc(1,income)],fileName,"WriteMode","append");
            case 5
                writematrix([O_F_prsc(2,income),O_F_prsc(1,income)],fileName,"WriteMode","append");
        end
        writematrix("*WATTAGE (Standard Electric/ES Electric/Standard Gas/ES Gas)",fileName,"WriteMode","append");
        writematrix([Power_Info(appl,2),Power_Info(appl,3),Power_Info(appl,4),Power_Info(appl,5)],fileName,"WriteMode","append");
    end
    
end
disp("DONE")
%======================================
